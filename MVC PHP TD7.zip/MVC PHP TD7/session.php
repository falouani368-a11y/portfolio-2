<?php

session_start();

$_SESSION["login"] = "toto";
$_SESSION["age"] = 20;

echo "Session créée.<br>";

session_unset();
session_destroy();

echo "Session supprimée.";

?>