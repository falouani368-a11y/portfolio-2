<?php

if (isset($_COOKIE["Panier"])) {

    $panier = unserialize($_COOKIE["Panier"]);

    foreach ($panier as $produit) {
        echo $produit . "<br>";
    }

} else {

    echo "Le panier n'existe pas";

}

?>
Tu do