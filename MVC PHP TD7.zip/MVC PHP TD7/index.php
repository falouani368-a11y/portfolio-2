<?php

session_start();

// Vérifier si le panier existe et s'il a expiré
if (isset($_SESSION["expiration"])) {

    if (time() - $_SESSION["expiration"] > 10) {

        session_unset();
        session_destroy();

        echo "Le panier a expiré.";

        exit;
    }
}

// Créer le panier s'il n'existe pas
if (!isset($_SESSION["panier"])) {

    $_SESSION["panier"] = [
        [
            "nom" => "Produit 1",
            "prix" => 10,
            "quantite" => 2
        ],
        [
            "nom" => "Produit 2",
            "prix" => 15,
            "quantite" => 1
        ]
    ];
}

// Calculer le prix
$total = 0;

foreach ($_SESSION["panier"] as $produit) {
    $total += $produit["prix"] * $produit["quantite"];
}

$_SESSION["prix_panier"] = $total;

// Enregistrer l'heure
$_SESSION["expiration"] = time();

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panier</title>
</head>
<body>

<h1>Mon panier</h1>

<?php

foreach ($_SESSION["panier"] as $produit) {

    echo $produit["nom"] . " - ";
    echo $produit["prix"] . " € - ";
    echo "Quantité : " . $produit["quantite"];
    echo "<br>";

}

?>

<h2>Total : <?php echo $_SESSION["prix_panier"]; ?> €</h2>

<p>Le panier expire après 10 secondes sans activité.</p>

</body>
</html>