<?php

if (isset($_POST["preference"])) {

    $preference = $_POST["preference"];

    setcookie("preference", $preference, time() + 3600);

    echo "Votre préférence a été enregistrée : " . $preference;

} else {

    echo "Aucune préférence sélectionnée.";

}

?>