
import { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";

import Header from "./components/Header";

import Accueil from "./pages/Accueil";
import Tickets from "./pages/Tickets";
import Nouveau from "./pages/Nouveau";
import Detail from "./pages/Detail";
import NotFound from "./pages/NotFound";

function App() {
  const [traites, setTraites] = useState(0);
  const [tickets, setTickets] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState("");

  // Charger les tickets depuis l'API
  useEffect(() => {
    async function charger() {
      try {
        const reponse = await fetch("http://localhost:3001/tickets");

        if (!reponse.ok) {
          throw new Error("Erreur " + reponse.status);
        }

        const donnees = await reponse.json();
        setTickets(donnees);
      } catch (e) {
        setErreur(e.message);
      } finally {
        setChargement(false);
      }
    }

    charger();
  }, []);

  // Ajouter un ticket
  const ajouterTicket = async (nouveauTicket) => {
    try {
      const reponse = await fetch("http://localhost:3001/tickets", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(nouveauTicket)
      });

      if (!reponse.ok) {
        throw new Error("Erreur lors de l'ajout");
      }

      const ticketAjoute = await reponse.json();

      setTickets((anciens) => [...anciens, ticketAjoute]);
      setErreur("");
      return true;
    } catch (e) {
      setErreur(e.message);
      return false;
    }
  };

  // Supprimer un ticket
  const supprimerTicket = async (id) => {
    try {
      const reponse = await fetch(
        `http://localhost:3001/tickets/${id}`,
        { method: "DELETE" }
      );

      if (!reponse.ok) {
        throw new Error("Erreur lors de la suppression");
      }

      setTickets((anciens) =>
        anciens.filter((t) => t.id !== id)
      );

      setErreur("");
    } catch (e) {
      setErreur(e.message);
    }
  };

  // Modifier le statut
  const changerStatut = async (id, nouveauStatut) => {
    try {
      const reponse = await fetch(
        `http://localhost:3001/tickets/${id}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ statut: nouveauStatut })
        }
      );

      if (!reponse.ok) {
        throw new Error("Erreur lors de la modification");
      }

      const ticketModifie = await reponse.json();

      setTickets((anciens) =>
        anciens.map((t) =>
          t.id === id ? ticketModifie : t
        )
      );

      setErreur("");
    } catch (e) {
      setErreur(e.message);
    }
  };

  if (chargement) {
    return (
      <div>
        <Header />
        <p>Chargement...</p>
      </div>
    );
  }

  return (
    <div>
      <Header />

      {erreur && <p style={{ color: "red" }}>{erreur}</p>}

      <Routes>
        <Route
          path="/"
          element={<Accueil tickets={tickets} />}
        />

        <Route
          path="/tickets"
          element={
            <Tickets
              tickets={tickets}
              supprimerTicket={supprimerTicket}
              changerStatut={changerStatut}
            />
          }
        />

        <Route
          path="/tickets/nouveau"
          element={<Nouveau ajouterTicket={ajouterTicket} />}
        />

        <Route
          path="/tickets/:id"
          element={<Detail tickets={tickets} />}
        />

        <Route
          path="*"
          element={<NotFound />}
        />
      </Routes>

      <hr />

      <h2>Compteur de tickets traités</h2>

      <p>Tickets traités : {traites}</p>

      <button onClick={() => setTraites(traites + 1)}>
        Marquer un ticket comme traité
      </button>

      <button onClick={() => setTraites(0)}>
        Remettre à zéro
      </button>

      <button onClick={() => setTraites(Math.max(0, traites - 1))}>
        Annuler
      </button>
    </div>
  );
}

export default App;
