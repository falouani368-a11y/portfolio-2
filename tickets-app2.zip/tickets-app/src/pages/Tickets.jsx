
import { useState } from "react";
import TicketList from "../components/TicketList";

function Tickets({ tickets, supprimerTicket, changerStatut }) {
  const [recherche, setRecherche] = useState("");
  const [statutFiltre, setStatutFiltre] = useState("Tous");
  const [triPriorite, setTriPriorite] = useState(false);

  // Recherche et filtre
  let ticketsAffiches = tickets
    .filter((t) =>
      t.titre.toLowerCase().includes(recherche.toLowerCase())
    )
    .filter((t) =>
      statutFiltre === "Tous" || t.statut === statutFiltre
    );

  // Tri par priorité
  if (triPriorite) {
    const ordre = {
      Haute: 1,
      Moyenne: 2,
      Basse: 3
    };

    ticketsAffiches = [...ticketsAffiches].sort(
      (a, b) => ordre[a.priorite] - ordre[b.priorite]
    );
  }

  return (
    <div>
      <h2>Liste des tickets</h2>

      <label>Rechercher :</label>
      <input
        type="text"
        placeholder="Rechercher par titre..."
        value={recherche}
        onChange={(e) => setRecherche(e.target.value)}
      />

      <br />

      <label>Filtrer par statut :</label>
      <select
        value={statutFiltre}
        onChange={(e) => setStatutFiltre(e.target.value)}
      >
        <option value="Tous">Tous</option>
        <option value="Ouvert">Ouvert</option>
        <option value="En cours">En cours</option>
        <option value="Résolu">Résolu</option>
      </select>

      <br />

      <button onClick={() => setTriPriorite(!triPriorite)}>
        {triPriorite ? "Désactiver le tri" : "Trier par priorité"}
      </button>

      <p>
        {ticketsAffiches.length} ticket(s) affiché(s) sur {tickets.length}
      </p>

      <TicketList
        tickets={ticketsAffiches}
        supprimerTicket={supprimerTicket}
        changerStatut={changerStatut}
      />
    </div>
  );
}

export default Tickets;
