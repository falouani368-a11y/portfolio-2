
import { useNavigate } from "react-router-dom";
import TicketForm from "../components/TicketForm";

function Nouveau({ ajouterTicket }) {
  const navigate = useNavigate();

  const handleAjouter = async (ticket) => {
    const succes = await ajouterTicket(ticket);

    if (succes) {
      navigate("/tickets");
    }
  };

  return (
    <div>
      <h2>Ajouter un nouveau ticket</h2>

      <TicketForm onAjouter={handleAjouter} />
    </div>
  );
}

export default Nouveau;
