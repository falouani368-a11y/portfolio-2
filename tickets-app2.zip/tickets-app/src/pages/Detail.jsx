
import { useParams, Link } from "react-router-dom";

function Detail({ tickets }) {
  const { id } = useParams();

  const ticket = tickets.find(
    (t) => String(t.id) === id
  );

  if (!ticket) {
    return (
      <div>
        <h2>Ticket introuvable</h2>
        <Link to="/tickets">Retour aux tickets</Link>
      </div>
    );
  }

  return (
    <div>
      <h2>Détail du ticket</h2>

      <h3>{ticket.titre}</h3>

      <p>ID : {ticket.id}</p>
      <p>Auteur : {ticket.auteur}</p>
      <p>Priorité : {ticket.priorite}</p>
      <p>Statut : {ticket.statut}</p>
      <p>Description : {ticket.description || "Aucune description"}</p>

      <Link to="/tickets">Retour à la liste</Link>
    </div>
  );
}

export default Detail;
