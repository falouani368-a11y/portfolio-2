
function Accueil({ tickets }) {
  const total = tickets.length;

  const ouverts = tickets.filter(
    (t) => t.statut === "Ouvert"
  ).length;

  const enCours = tickets.filter(
    (t) => t.statut === "En cours"
  ).length;

  const resolus = tickets.filter(
    (t) => t.statut === "Résolu"
  ).length;

  return (
    <div>
      <h2>Bienvenue sur WebDev Solutions</h2>

      <p>Application de gestion des tickets informatiques.</p>

      <h3>Statistiques des tickets</h3>

      <p>Nombre total de tickets : {total}</p>
      <p>Tickets ouverts : {ouverts}</p>
      <p>Tickets en cours : {enCours}</p>
      <p>Tickets résolus : {resolus}</p>
    </div>
  );
}

export default Accueil;
