
import { Link } from "react-router-dom";

function NotFound() {
  return (
    <div>
      <h2>Erreur 404</h2>

      <p>La page demandée n'existe pas.</p>

      <Link to="/">Retour à l'accueil</Link>
    </div>
  );
}

export default NotFound;
