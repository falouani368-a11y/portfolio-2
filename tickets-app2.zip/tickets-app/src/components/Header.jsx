
import { NavLink } from "react-router-dom";

function Header() {
  return (
    <header>
      <h1>Gestion des tickets</h1>

      <nav>
        <NavLink to="/">Accueil</NavLink>
        {" | "}
        <NavLink to="/tickets">Tickets</NavLink>
        {" | "}
        <NavLink to="/tickets/nouveau">Ajouter un ticket</NavLink>
      </nav>

      <hr />
    </header>
  );
}

export default Header;
