
import { Link } from "react-router-dom";

function Ticket({
  id,
  titre,
  auteur,
  priorite,
  statut,
  supprimerTicket,
  changerStatut
}) {
  return (
    <div>
      <h3>{titre}</h3>

      <p>Auteur : {auteur}</p>
      <p>Priorité : {priorite}</p>
      <p>Statut : {statut}</p>

      <select
        value={statut}
        onChange={(e) => changerStatut(id, e.target.value)}
      >
        <option value="Ouvert">Ouvert</option>
        <option value="En cours">En cours</option>
        <option value="Résolu">Résolu</option>
      </select>

      <button onClick={() => supprimerTicket(id)}>
        Supprimer
      </button>

      <Link to={`/tickets/${id}`}>
        Voir le détail
      </Link>

      <hr />
    </div>
  );
}

export default Ticket;
