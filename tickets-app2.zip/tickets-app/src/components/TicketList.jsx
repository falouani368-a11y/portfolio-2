
import Ticket from "./Ticket";

function TicketList({ tickets, supprimerTicket, changerStatut }) {
  return (
    <div>
      <h2>Liste des tickets</h2>

      {tickets.map((t) => (
        <Ticket
          key={t.id}
          {...t}
          supprimerTicket={supprimerTicket}
          changerStatut={changerStatut}
        />
      ))}
    </div>
  );
}

export default TicketList;
