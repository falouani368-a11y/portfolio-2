
import { useState } from "react";

function TicketForm({ onAjouter }) {
  const [form, setForm] = useState({
    titre: "",
    auteur: "",
    priorite: "Moyenne",
    description: ""
  });

  const [erreurs, setErreurs] = useState({});

  // Modifier les champs du formulaire
  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  // Vérifier et envoyer le formulaire
  const handleSubmit = (e) => {
    e.preventDefault();

    const nouvellesErreurs = {};

    if (form.titre.trim().length < 5) {
      nouvellesErreurs.titre =
        "Le titre doit contenir au moins 5 caractères.";
    }

    if (form.auteur.trim() === "") {
      nouvellesErreurs.auteur =
        "L'auteur est obligatoire.";
    }

    setErreurs(nouvellesErreurs);

    if (Object.keys(nouvellesErreurs).length > 0) {
      return;
    }

    // Ajouter le nouveau ticket
    onAjouter({
      ...form,
      id: Date.now(),
      statut: "Ouvert"
    });

    // Réinitialiser le formulaire
    setForm({
      titre: "",
      auteur: "",
      priorite: "Moyenne",
      description: ""
    });

    setErreurs({});
  };

  return (
    <div>
      <h2>Ajouter un ticket</h2>

      <form onSubmit={handleSubmit}>
        <div>
          <label>Titre :</label>
          <input
            type="text"
            name="titre"
            value={form.titre}
            onChange={handleChange}
          />
          {erreurs.titre && <p>{erreurs.titre}</p>}
        </div>

        <div>
          <label>Auteur :</label>
          <input
            type="text"
            name="auteur"
            value={form.auteur}
            onChange={handleChange}
          />
          {erreurs.auteur && <p>{erreurs.auteur}</p>}
        </div>

        <div>
          <label>Priorité :</label>
          <select
            name="priorite"
            value={form.priorite}
            onChange={handleChange}
          >
            <option value="Haute">Haute</option>
            <option value="Moyenne">Moyenne</option>
            <option value="Basse">Basse</option>
          </select>
        </div>

        <div>
          <label>Description :</label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
          />
        </div>

        <button type="submit">Ajouter le ticket</button>
      </form>
    </div>
  );
}

export default TicketForm;
