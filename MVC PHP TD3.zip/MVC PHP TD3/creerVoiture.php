<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Création voiture</title>
</head>
<body>

<?php

require_once 'Model.php';
require_once 'Voiture.php';

$immatriculation = $_POST["immatriculation"];
$marque = $_POST["marque"];
$couleur = $_POST["couleur"];

$voiture = new Voiture($immatriculation, $marque, $couleur);

if ($voiture->save()) {
    echo "Voiture enregistrée avec succès.<br>";
} else {
    echo "Erreur lors de l'enregistrement.<br>";
}

?>

<p>
    Voiture <?php echo $immatriculation; ?>
    de marque <?php echo $marque; ?>
    (couleur <?php echo $couleur; ?>)
</p>

</body>
</html>
