<?php

require_once 'Model.php';
require_once 'Voiture.php';

$voiture = new Voiture("ZZ999ZZ", "Toyota", "Vert");

if ($voiture->save()) {
    echo "Voiture enregistrée avec succès.";
} else {
    echo "Erreur lors de l'enregistrement.";
}

?>
