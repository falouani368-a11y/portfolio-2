<?php

require_once 'Model.php';
require_once 'Utilisateur.php';
require_once 'Trajet.php';

$login = $_GET['login'];

$tab_trajets = Utilisateur::findTrajets($login);

foreach ($tab_trajets as $trajet) {
    echo "Départ : " . $trajet->getDepart() . "<br>";
    echo "Arrivée : " . $trajet->getArrivee() . "<br>";
    echo "Date : " . $trajet->getDate() . "<br>";
    echo "Nombre de places : " . $trajet->getNbplaces() . "<br>";
    echo "Prix : " . $trajet->getPrix() . "<br><br>";
}

?>
