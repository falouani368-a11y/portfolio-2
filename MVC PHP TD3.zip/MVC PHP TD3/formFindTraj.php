<form method="get" action="testFindTraj.php">

    <label>Login de l'utilisateur :</label>
    <input type="text" name="login">

    <input type="submit" value="Rechercher">

</form>
