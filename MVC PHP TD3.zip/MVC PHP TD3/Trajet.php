<?php

class Trajet {

    private $id;
    private $depart;
    private $arrivee;
    private $date;
    private $nbplaces;
    private $prix;
    private $conducteur_login;

    public function getDepart() {
        return $this->depart;
    }

    public function getArrivee() {
        return $this->arrivee;
    }

    public function getDate() {
        return $this->date;
    }

    public function getNbplaces() {
        return $this->nbplaces;
    }

    public function getPrix() {
        return $this->prix;
    }

    public function getConducteurLogin() {
        return $this->conducteur_login;
    }

    public static function findPassagers($id) {

        $sql = "SELECT utilisateur.*
                FROM utilisateur
                INNER JOIN passager
                ON utilisateur.login = passager.utilisateur_login
                WHERE passager.trajet_id = :id";

        $req_prep = Model::$pdo->prepare($sql);

        $values = array(
            "id" => $id
        );

        $req_prep->execute($values);

        $req_prep->setFetchMode(PDO::FETCH_CLASS, "Utilisateur");

        return $req_prep->fetchAll();
    }
}
?>
