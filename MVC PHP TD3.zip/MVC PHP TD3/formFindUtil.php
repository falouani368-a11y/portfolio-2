<form method="get" action="testFindUtil.php">
    <label>Identifiant du trajet :</label>
    <input type="text" name="id">
    <input type="submit" value="Rechercher">
</form>
