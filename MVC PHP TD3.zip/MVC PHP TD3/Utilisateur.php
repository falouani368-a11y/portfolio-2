<?php

class Utilisateur {

    private $login;
    private $nom;
    private $prenom;

    public function __construct($login = NULL, $nom = NULL, $prenom = NULL) {
        $this->login = $login;
        $this->nom = $nom;
        $this->prenom = $prenom;
    }

    public function afficher() {
        echo "Login : " . $this->login . "<br>";
        echo "Nom : " . $this->nom . "<br>";
        echo "Prénom : " . $this->prenom . "<br><br>";
    }

    public static function findTrajets($login) {
        $sql = "SELECT trajet.*
                FROM trajet
                INNER JOIN passager
                ON trajet.id = passager.trajet_id
                WHERE passager.utilisateur_login = :login";

        $req_prep = Model::$pdo->prepare($sql);

        $values = array(
            "login" => $login
        );

        $req_prep->execute($values);

        $req_prep->setFetchMode(PDO::FETCH_CLASS, "Trajet");

        return $req_prep->fetchAll();
    }
}

?>
