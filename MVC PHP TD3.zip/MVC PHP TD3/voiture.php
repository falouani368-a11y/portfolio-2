<?php

class Voiture {

    private $immatriculation;
    private $marque;
    private $couleur;
    private $dateImmat;

    public function __construct($immatriculation = NULL, $marque = NULL, $couleur = NULL, $dateImmat = NULL) {
        $this->immatriculation = $immatriculation;
        $this->marque = $marque;
        $this->couleur = $couleur;
        $this->dateImmat = $dateImmat;
    }

    public function getImmatriculation() {
        return $this->immatriculation;
    }

    public function getMarque() {
        return $this->marque;
    }

    public function getCouleur() {
        return $this->couleur;
    }

    public function getDateImmat() {
        return $this->dateImmat;
    }

    public function afficher() {
        echo "Immatriculation : " . $this->immatriculation . "<br>";
        echo "Marque : " . $this->marque . "<br>";
        echo "Couleur : " . $this->couleur . "<br>";
        echo "Date d'immatriculation : " . $this->dateImmat . "<br>";
    }

    public static function getVoitureByImmat($immat) {

        $sql = "SELECT * FROM voiture WHERE immatriculation = :immat";

        try {
            $req_prep = Model::$pdo->prepare($sql);

            $values = array(
                "immat" => $immat
            );

            $req_prep->execute($values);

            $req_prep->setFetchMode(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Voiture');

            $tab_voit = $req_prep->fetchAll();

            if (empty($tab_voit)) {
                return false;
            }

            return $tab_voit[0];

        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return false;
        }
    }

    public function save() {

        $sql = "INSERT INTO voiture (immatriculation, marque, couleur)
                VALUES (:immat, :marque, :couleur)";

        try {
            $req_prep = Model::$pdo->prepare($sql);

            $values = array(
                "immat" => $this->immatriculation,
                "marque" => $this->marque,
                "couleur" => $this->couleur
            );

            $req_prep->execute($values);

            return true;

        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return false;
        }
    }
}
?>
