<?php

require_once 'Model.php';
require_once 'Utilisateur.php';
require_once 'Trajet.php';

$id = $_GET['id'];
$tab_util = Trajet::findPassagers($id);


foreach ($tab_util as $utilisateur) {
    $utilisateur->afficher();
}

?>
