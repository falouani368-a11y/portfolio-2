<?php

namespace App\Service;

use App\Entity\Emprunt;
use App\Entity\Livre;
use App\Entity\User;
use App\Repository\EmpruntRepository;
use Doctrine\ORM\EntityManagerInterface;

class EmpruntService
{
    public function __construct(
        private EntityManagerInterface $entityManager,
        private EmpruntRepository $empruntRepository,
    ) {
    }

    public function emprunter(User $user, Livre $livre): Emprunt
    {
        if ($this->empruntRepository->countEnCoursPourUser($user) >= 3) {
            throw new \DomainException("Vous avez déjà atteint la limite de 3 emprunts en cours.");
        }

        if ($this->empruntRepository->countEnCoursPourLivre($livre) >= $livre->getNbExemplaires()) {
            throw new \DomainException("Aucun exemplaire de ce livre n'est actuellement disponible.");
        }

        $dateEmprunt = new \DateTimeImmutable();
        $emprunt = (new Emprunt())
            ->setUser($user)
            ->setLivre($livre)
            ->setDateEmprunt($dateEmprunt)
            ->setDateRetourPrevue($dateEmprunt->modify('+14 days'));

        $this->entityManager->persist($emprunt);
        $this->entityManager->flush();

        return $emprunt;
    }
}