<?php

namespace App\Controller;

use App\Entity\Livre;
use App\Entity\User;
use App\Form\LivreType;
use App\Repository\LivreRepository;
use App\Service\EmpruntService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

class LivreController extends AbstractController
{
    #[Route('/livres', name: 'livre_index', methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function index(Request $request, LivreRepository $livreRepository): Response
    {
        $q = trim((string) $request->query->get('q', ''));

        return $this->render('livre/index.html.twig', [
            'livres' => $livreRepository->search($q),
            'q' => $q,
        ]);
    }

    #[Route('/livres/{id}', name: 'livre_show', methods: ['GET'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_USER')]
    public function show(Livre $livre): Response
    {
        return $this->render('livre/show.html.twig', [
            'livre' => $livre,
        ]);
    }

    #[Route('/livres/nouveau', name: 'livre_new', methods: ['GET', 'POST'])]
    #[IsGranted('ROLE_DOCUMENTALISTE')]
    public function new(Request $request, EntityManagerInterface $em): Response
    {
        $livre = new Livre();
        $form = $this->createForm(LivreType::class, $livre);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($livre);
            $em->flush();

            $this->addFlash('success', 'Le livre a été ajouté au catalogue.');

            return $this->redirectToRoute('livre_index');
        }

        return $this->render('livre/new.html.twig', [
            'form' => $form,
        ]);
    }

    #[Route('/livres/{id}/modifier', name: 'livre_edit', methods: ['GET', 'POST'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_DOCUMENTALISTE')]
    public function edit(Request $request, Livre $livre, EntityManagerInterface $em): Response
    {
        $form = $this->createForm(LivreType::class, $livre);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();

            $this->addFlash('success', 'Le livre a été modifié.');

            return $this->redirectToRoute('livre_show', ['id' => $livre->getId()]);
        }

        return $this->render('livre/edit.html.twig', [
            'livre' => $livre,
            'form' => $form,
        ]);
    }

    #[Route('/livres/{id}/supprimer', name: 'livre_delete', methods: ['POST'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_DOCUMENTALISTE')]
    public function delete(Request $request, Livre $livre, EntityManagerInterface $em): Response
    {
        if (!$this->isCsrfTokenValid('delete_livre_' . $livre->getId(), (string) $request->request->get('_token'))) {
            $this->addFlash('danger', 'Le jeton de sécurité est invalide.');

            return $this->redirectToRoute('livre_show', ['id' => $livre->getId()]);
        }

        $em->remove($livre);
        $em->flush();

        $this->addFlash('success', 'Le livre a été supprimé.');

        return $this->redirectToRoute('livre_index');
    }

    #[Route('/livres/{id}/emprunter', name: 'livre_emprunter', methods: ['POST'], requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_USER')]
    public function emprunter(Request $request, Livre $livre, EmpruntService $empruntService): Response
    {
        if (!$this->isCsrfTokenValid('emprunter_' . $livre->getId(), (string) $request->request->get('_token'))) {
            $this->addFlash('danger', 'Le jeton de sécurité est invalide.');

            return $this->redirectToRoute('livre_show', ['id' => $livre->getId()]);
        }

        $user = $this->getUser();
        if (!$user instanceof User) {
            throw $this->createAccessDeniedException();
        }

        try {
            $empruntService->emprunter($user, $livre);
            $this->addFlash('success', 'Le livre a été emprunté.');
        } catch (\DomainException $exception) {
            $this->addFlash('danger', $exception->getMessage());
        }

        return $this->redirectToRoute('livre_show', ['id' => $livre->getId()]);
    }
}
