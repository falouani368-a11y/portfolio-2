# Diagnostic et corrections

Les références ci-dessous donnent le fichier et la ligne du code corrigé. Les erreurs signalées dans `var/log/dev.log` sont des symptômes ; le code applicatif, et non le fichier du vendor, en est la cause.

| # | Symptôme observé | Cause | Correction appliquée |
|---|---|---|---|
| 1 | `/livres/nouveau` renvoyait une erreur « livre introuvable » : la route dynamique `/livres/{id}` capturait `nouveau`. Le journal montrait l'échec de résolution d'entité dans `EntityValueResolver`. | `src/Controller/LivreController.php:31` : route `livre_show` sans contrainte numérique sur `{id}`. | Contraindre les identifiants de `livre_show`, `livre_edit` et `livre_delete` à des chiffres afin que `nouveau` ne soit pas interprété comme un identifiant. |
| 2 | Une recherche construite spécialement pouvait modifier la requête DQL au lieu de chercher uniquement un titre. | `src/Repository/LivreRepository.php:32` : concaténation directe du texte recherché dans `LIKE`. | Utiliser un paramètre lié `:q` pour la recherche. |
| 3 | Un élève connecté pouvait atteindre les fonctions de gestion du catalogue, car la règle générale des livres était vérifiée avant la règle documentaliste. | `config/packages/security.yaml:32-33` : ordre des entrées `access_control`. | Évaluer d'abord la règle `ROLE_DOCUMENTALISTE`, puis exiger `ROLE_USER` pour le reste du catalogue ; ajouter aussi des contrôles d'accès sur les actions du contrôleur. |
| 4 | La description d'un livre pouvait exécuter du HTML ou du JavaScript fourni dans son contenu. | `templates/livre/show.html.twig:15` : filtre `raw` désactivant l'échappement Twig. | Supprimer `raw` pour laisser Twig échapper le contenu. |
| 5 | Après soumission valide du formulaire d'ajout, le livre n'était pas enregistré. | `src/Controller/LivreController.php:49` : `new()` persistait l'entité sans appeler `flush()`. | Appeler `flush()` après `persist()`. |
| 6 | La suppression était déclenchée par un lien GET, donc sans protection CSRF et avec un effet de bord sur une requête de navigation. | `src/Controller/LivreController.php:83,87` et `templates/livre/show.html.twig:33` : suppression sans restriction de méthode ni contrôle du jeton. | Restreindre la route à POST, exiger le rôle documentaliste et vérifier un jeton CSRF transmis par un formulaire POST. |

# Règle de prêt

`src/Service/EmpruntService.php` applique la limite de trois emprunts en cours par utilisateur et vérifie le nombre d'exemplaires encore disponibles. Si une règle est violée, le service lève une `DomainException` avec un message explicite ; sinon, il enregistre un emprunt dont le retour est prévu 14 jours après la date d'emprunt.

La route `livre_emprunter` accepte uniquement POST, exige un utilisateur connecté et vérifie son jeton CSRF. La fiche du livre affiche le formulaire d'emprunt uniquement aux utilisateurs connectés. Le contrôleur affiche le résultat en message flash puis redirige vers la fiche du livre.

## Validation

- `php bin/console debug:router` : routes et méthodes contrôlées.
- `composer check-platform-reqs` : dépendances compatibles avec PHP 8.4.
- Migration Doctrine exécutée avec succès avant l'implémentation de cette règle.
