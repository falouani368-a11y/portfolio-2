
import { useState } from "react";
import Header from "./components/Header";
import Ticket from "./components/Ticket";

function App() {
  const [traites, setTraites] = useState(0);

  const tickets = [
    {
      id: 1,
      titre: "Imprimante en panne",
      auteur: "M. Durand",
      priorite: "Haute",
      statut: "Ouvert"
    },
    {
      id: 2,
      titre: "Accès VPN refusé",
      auteur: "Mme Martin",
      priorite: "Moyenne",
      statut: "En cours"
    },
    {
      id: 3,
      titre: "Écran qui clignote",
      auteur: "M. Petit",
      priorite: "Basse",
      statut: "Résolu"
    }
  ];

  return (
    <div>
      <Header />

      <p>Bienvenue sur l'application WebDev Solutions.</p>

      <h2>Liste des tickets</h2>

      {tickets.map((t) => (
        <Ticket key={t.id} {...t} />
      ))}

      <hr />

      <h2>Compteur de tickets traités</h2>

      <p>Tickets traités : {traites}</p>

      <button onClick={() => setTraites(traites + 1)}>
        Marquer un ticket comme traité
      </button>

      <button onClick={() => setTraites(0)}>
        Remettre à zéro
      </button>

      <button onClick={() => setTraites(Math.max(0, traites - 1))}>
        Annuler
      </button>
    </div>
  );
}

export default App;
