function Ticket({ titre, auteur, priorite, statut }) {
  return (
    <div className="ticket">
      <h3>{titre}</h3>
      <p>Déclaré par : {auteur}</p>
      <p>Priorité : {priorite}</p>

      <p style={{
        color:
          statut === "Ouvert" ? "red" :
          statut === "En cours" ? "orange" :
          statut === "Résolu" ? "green" :
          "black",
        fontWeight: "bold"
      }}>
        STATUT : {statut}
      </p>
    </div>
  );
}

export default Ticket;