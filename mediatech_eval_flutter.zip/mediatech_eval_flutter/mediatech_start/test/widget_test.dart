import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:mediatech/main.dart';
import 'package:mediatech/services/api_service.dart';

http.Response _json(Object corps, int code) => http.Response(
      jsonEncode(corps),
      code,
      headers: {'content-type': 'application/json; charset=utf-8'},
    );

ApiService _service(http.Response Function() reponse) => ApiService(
      client: MockClient((_) async => reponse()),
      baseUrl: 'http://test',
    );

final _troisLivres = [
  {
    'id': 1,
    'titre': 'Le Petit Prince',
    'auteur': 'Saint-Exupery',
    'annee': 1943,
    'resume': 'Un pilote rencontre un petit garcon.',
    'disponible': true,
  },
  {
    'id': 2,
    'titre': 'Les Miserables',
    'auteur': 'Victor Hugo',
    'annee': 1862,
    'resume': 'Le destin de Jean Valjean.',
    'disponible': false,
  },
  {
    'id': 3,
    'titre': 'Candide',
    'auteur': 'Voltaire',
    'annee': 1759,
    'resume': 'Le jeune Candide parcourt le monde.',
    'disponible': true,
  },
];

void main() {
  testWidgets('le catalogue affiche le titre et un livre', (tester) async {
    await tester.pumpWidget(
      MediaTechApp(api: _service(() => _json(_troisLivres, 200))),
    );
    await tester.pumpAndSettle();

    expect(find.text('MediaTech'), findsOneWidget);
    expect(find.text('Le Petit Prince'), findsOneWidget);
  });

  testWidgets('le catalogue affiche aussi le dernier livre reçu',
      (tester) async {
    await tester.pumpWidget(
      MediaTechApp(api: _service(() => _json(_troisLivres, 200))),
    );
    await tester.pumpAndSettle();

    expect(find.text('Candide'), findsOneWidget);
  });

  testWidgets('une erreur réseau affiche un message et « Réessayer »',
      (tester) async {
    final api = ApiService(
      client: MockClient((_) async => throw http.ClientException('hors ligne')),
      baseUrl: 'http://test',
    );
    await tester.pumpWidget(
      MediaTechApp(api: api),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('Impossible de joindre le serveur'),
        findsOneWidget);
    expect(find.text('Réessayer'), findsOneWidget);
  });

  testWidgets(
      'une erreur au rechargement conserve la liste et propose une reprise',
      (tester) async {
    var appels = 0;
    final api = ApiService(
      client: MockClient((_) async {
        appels++;
        return appels == 1
            ? _json([_troisLivres.first], 200)
            : _json({'erreur': 'indisponible'}, 500);
      }),
      baseUrl: 'http://test',
    );

    await tester.pumpWidget(MediaTechApp(api: api));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('Actualiser'));
    await tester.pumpAndSettle();

    expect(find.text('Le Petit Prince'), findsOneWidget);
    expect(find.text('Réessayer'), findsOneWidget);
  });

  testWidgets('une liste vide affiche un message dédié', (tester) async {
    await tester.pumpWidget(
      MediaTechApp(api: _service(() => _json([], 200))),
    );
    await tester.pumpAndSettle();

    expect(find.text('Aucun livre dans le catalogue.'), findsOneWidget);
  });

  testWidgets('un appui sur un livre ouvre son détail', (tester) async {
    await tester.pumpWidget(
      MediaTechApp(api: _service(() => _json(_troisLivres, 200))),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('Le Petit Prince'));
    await tester.pumpAndSettle();

    expect(find.text('Année : 1943'), findsOneWidget);
  });

  testWidgets('les données manquantes ont un affichage de remplacement',
      (tester) async {
    final livreIncomplet = {
      'id': 7,
      'titre': 'Vendredi ou la Vie sauvage',
      'auteur': 'Michel Tournier',
      'disponible': true,
    };
    await tester.pumpWidget(
      MediaTechApp(api: _service(() => _json([livreIncomplet], 200))),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('année inconnue'), findsOneWidget);
    await tester.tap(find.text('Vendredi ou la Vie sauvage'));
    await tester.pumpAndSettle();

    expect(find.text('Année inconnue'), findsOneWidget);
    expect(
      find.text('Résumé : Aucun résumé disponible.'),
      findsOneWidget,
    );
  });

  testWidgets('un livre emprunté ne permet pas de lancer une réservation',
      (tester) async {
    await tester.pumpWidget(
      MediaTechApp(
        api: _service(() => _json([_troisLivres[1]], 200)),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('Les Miserables'));
    await tester.pumpAndSettle();

    final bouton = tester.widget<FilledButton>(
      find.widgetWithText(FilledButton, 'Réserver'),
    );
    expect(bouton.onPressed, isNull);
  });

  testWidgets('le formulaire nettoie le nom et envoie une seule réservation',
      (tester) async {
    http.Request? requeteReservation;
    var livreDisponible = true;
    final api = ApiService(
      client: MockClient((requete) async {
        if (requete.method == 'GET') {
          return _json([
            {..._troisLivres.first, 'disponible': livreDisponible},
          ], 200);
        }
        requeteReservation = requete;
        livreDisponible = false;
        return _json({'id': 5, 'statut': 'confirmee'}, 201);
      }),
      baseUrl: 'http://test',
    );

    await tester.pumpWidget(MediaTechApp(api: api));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Le Petit Prince'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Réserver'));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextFormField).at(0), '   ');
    await tester.enterText(
      find.byType(TextFormField).at(1),
      'Jean+test@Example.fr',
    );
    await tester.tap(find.text('Confirmer la réservation'));
    await tester.pumpAndSettle();
    expect(find.text('Le nom est obligatoire.'), findsOneWidget);
    expect(requeteReservation, isNull);

    await tester.enterText(find.byType(TextFormField).at(0), '  Jean Dupont  ');
    await tester.enterText(
        find.byType(TextFormField).at(1), 'adresse-invalide');
    await tester.tap(find.text('Confirmer la réservation'));
    await tester.pumpAndSettle();
    expect(find.text('Saisissez une adresse e-mail valide.'), findsOneWidget);
    expect(requeteReservation, isNull);

    await tester.enterText(
      find.byType(TextFormField).at(1),
      'Jean+test@Example.fr',
    );
    await tester.tap(find.text('Confirmer la réservation'));
    await tester.pumpAndSettle();

    expect(requeteReservation, isNotNull);
    expect(jsonDecode(requeteReservation!.body), {
      'livreId': 1,
      'nom': 'Jean Dupont',
      'email': 'Jean+test@Example.fr',
    });
    expect(find.text('MediaTech'), findsOneWidget);
    expect(find.textContaining('Réservation confirmée'), findsOneWidget);
    expect(find.text('Emprunté'), findsOneWidget);
  });

  testWidgets('le bouton bloque les doubles envois et montre le chargement',
      (tester) async {
    final reservation = Completer<http.Response>();
    var nombreDeReservations = 0;
    final api = ApiService(
      client: MockClient((requete) async {
        if (requete.method == 'GET') return _json([_troisLivres.first], 200);
        nombreDeReservations++;
        return reservation.future;
      }),
      baseUrl: 'http://test',
    );

    await tester.pumpWidget(MediaTechApp(api: api));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Le Petit Prince'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Réserver'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), 'Dupont');
    await tester.enterText(
      find.byType(TextFormField).at(1),
      'dupont@exemple.fr',
    );
    await tester.tap(find.text('Confirmer la réservation'));
    await tester.pump();

    expect(nombreDeReservations, 1);
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    expect(
      tester
          .widget<FilledButton>(
            find.byType(FilledButton),
          )
          .onPressed,
      isNull,
    );

    reservation.complete(_json({'id': 5, 'statut': 'confirmee'}, 201));
    await tester.pumpAndSettle();
    expect(find.textContaining('Réservation confirmée'), findsOneWidget);
  });

  testWidgets('une erreur API est affichée et le formulaire peut être renvoyé',
      (tester) async {
    var nombreDeReservations = 0;
    final api = ApiService(
      client: MockClient((requete) async {
        if (requete.method == 'GET') return _json([_troisLivres.first], 200);
        nombreDeReservations++;
        if (nombreDeReservations == 1) {
          return _json({
            'erreur': 'Données invalides.',
            'details': {'email': 'Adresse e-mail invalide.'},
          }, 422);
        }
        return _json({'id': 5, 'statut': 'confirmee'}, 201);
      }),
      baseUrl: 'http://test',
    );

    await tester.pumpWidget(MediaTechApp(api: api));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Le Petit Prince'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Réserver'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), 'Dupont');
    await tester.enterText(
      find.byType(TextFormField).at(1),
      'dupont@exemple.fr',
    );

    await tester.tap(find.text('Confirmer la réservation'));
    await tester.pumpAndSettle();
    expect(
      find.text('Données invalides. Adresse e-mail invalide.'),
      findsOneWidget,
    );
    expect(
      tester
          .widget<FilledButton>(
            find.byType(FilledButton),
          )
          .onPressed,
      isNotNull,
    );

    await tester.tap(find.text('Confirmer la réservation'));
    await tester.pumpAndSettle();
    expect(nombreDeReservations, 2);
    expect(find.textContaining('Réservation confirmée'), findsOneWidget);
  });
}
