import 'package:flutter_test/flutter_test.dart';
import 'package:mediatech/models/livre.dart';

void main() {
  test('fromJson accepte un résumé absent', () {
    final livre = Livre.fromJson({
      'id': 7,
      'titre': 'Vendredi ou la Vie sauvage',
      'auteur': 'Michel Tournier',
      'annee': 1971,
      'disponible': true,
    });

    expect(livre.id, 7);
    expect(livre.titre, 'Vendredi ou la Vie sauvage');
    expect(livre.auteur, 'Michel Tournier');
    expect(livre.annee, 1971);
    expect(livre.resume, isNull);
    expect(livre.disponible, isTrue);
  });
}
