# Partie 4 – Architecture, sécurité et tests

## 4.1 Architecture

```text
lib/
├── main.dart
├── models/
│   └── livre.dart
├── screens/
│   ├── catalogue_screen.dart
│   ├── detail_screen.dart
│   └── reservation_screen.dart
├── services/
│   ├── api_config.dart
│   └── api_service.dart
└── widgets/
    ├── disponibilite_chip.dart
    └── livre_tile.dart
```

Le service API sépare le transport HTTP et la gestion des erreurs de l'interface, ce qui évite de dupliquer la logique réseau dans les écrans.  
Les widgets restent ainsi centrés sur l'affichage et les interactions, et le service peut être remplacé par un faux dans les tests.  
Si l'application grossit, la gestion d'état peut être placée dans des contrôleurs/fournisseurs dédiés, par exemple avec le paquet `provider` déjà déclaré.

## 4.2 Sécurité et données personnelles

| Risque | Mesure |
| --- | --- |
| Le trafic HTTP en clair peut être intercepté et modifié. | Utiliser HTTPS avec une validation correcte du certificat en production ; ne pas autoriser le trafic en clair hors environnement de développement. |
| Un jeton volé peut être réutilisé pour usurper un compte. | Stocker le jeton dans le stockage sécurisé du système, limiter sa durée de vie et le révoquer/renouveler côté serveur. |

Sur le téléphone, je stockerais le jeton avec le paquet Flutter `flutter_secure_storage`, qui s'appuie sur le Keychain iOS et le stockage chiffré Android. Un fichier de préférences classique n'est pas conçu pour protéger des secrets et peut stocker les valeurs en clair ou les rendre accessibles avec les données de l'application.

Deux obligations RGPD applicables à la médiathèque :

- informer les adhérents de la finalité, de la base légale, de la durée de conservation et de leurs droits au moment de la collecte ;
- limiter la collecte et la conservation au nécessaire, protéger les adresses e-mail et permettre l'exercice des droits (notamment accès, rectification et effacement, selon les conditions applicables).

## 4.3 Tests

Un test unitaire vérifie isolément une fonction ou un modèle, sans construire l'interface.  
Un test de widget vérifie le rendu et les interactions d'un widget ; un test d'intégration vérifie l'application complète sur une cible d'exécution, souvent avec plusieurs composants réunis.

Le test unitaire demandé est dans [`test/livre_test.dart`](./test/livre_test.dart) : il vérifie que `Livre.fromJson` crée correctement un livre dont le champ `resume` est absent.
