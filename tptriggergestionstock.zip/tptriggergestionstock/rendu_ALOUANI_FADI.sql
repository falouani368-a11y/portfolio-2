-- Rendu TP Triggers : Fadi Alouani
-- N = 7 ; M = 9 ; initiale = F
-- MariaDB 10.4.32 ; schema attendu : tp_triggers
-- Tous les triggers finaux du TP, y compris les corrections et la regle personnelle.

USE tp_triggers;

DELIMITER $$

CREATE TRIGGER trg_produit_au
AFTER UPDATE ON produit
FOR EACH ROW
BEGIN

  -- Si le prix a changé, on garde son historique
  IF NOT (OLD.prix_ht <=> NEW.prix_ht) THEN

    INSERT INTO historique_prix
    (id_produit, ancien_prix, nouveau_prix, utilisateur)
    VALUES
    (NEW.id_produit, OLD.prix_ht, NEW.prix_ht, USER());

  END IF;

  -- Si le stock a changé, on écrit dans le journal
  IF NOT (OLD.stock <=> NEW.stock) THEN

    INSERT INTO journal
    (utilisateur, table_cible, action, detail)
    VALUES
    (USER(), 'produit', 'UPDATE',
     CONCAT('stock ', OLD.stock, ' -> ', NEW.stock));

  END IF;

END$$

CREATE TRIGGER trg_produit_ad
AFTER DELETE ON produit
FOR EACH ROW
BEGIN

  INSERT INTO journal
  (utilisateur, table_cible, action, detail)
  VALUES
  (USER(), 'produit', 'DELETE',
   CONCAT('id=', OLD.id_produit, ' ; libelle=', OLD.libelle));

END$$

CREATE TRIGGER trg_produit_bi
BEFORE INSERT ON produit
FOR EACH ROW
BEGIN

  -- Supprimer les espaces inutiles
  SET NEW.libelle = TRIM(NEW.libelle);

  -- Vérifier que le libellé n'est pas vide
  IF NEW.libelle = '' THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Libellé obligatoire';
  END IF;

  -- Refuser un prix inférieur ou égal à 0
  IF NEW.prix_ht <= 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Prix invalide';
  END IF;

  -- Refuser un stock négatif
  IF NEW.stock < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Stock négatif interdit';
  END IF;

END$$

CREATE TRIGGER trg_produit_bu
BEFORE UPDATE ON produit
FOR EACH ROW
BEGIN

  -- Nettoyer le libellé
  SET NEW.libelle = TRIM(NEW.libelle);

  -- Vérifier le libellé
  IF NEW.libelle = '' THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Libellé obligatoire à la modification';
  END IF;

  -- Vérifier le prix
  IF NEW.prix_ht <= 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Prix invalide à la modification';
  END IF;

  -- Vérifier le stock
  IF NEW.stock < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Stock négatif interdit à la modification';
  END IF;

  -- Initiale F : interdire une baisse de prix superieure a 30 %
  IF NEW.prix_ht < OLD.prix_ht * 0.70 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Baisse de prix superieure a 30 % interdite';
  END IF;

END$$

CREATE TRIGGER trg_ligne_bi
BEFORE INSERT ON ligne_commande
FOR EACH ROW
BEGIN
  DECLARE v_stock INT;
  DECLARE v_prix  DECIMAL(8,2);

  SELECT stock, prix_ht INTO v_stock, v_prix
  FROM produit
  WHERE id_produit = NEW.id_produit;

  IF NEW.quantite <= 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Quantité invalide';
  END IF;

  IF v_stock < NEW.quantite THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock insuffisant';
  END IF;

  SET NEW.prix_unitaire = v_prix;
END$$

CREATE TRIGGER trg_ligne_ai
AFTER INSERT ON ligne_commande
FOR EACH ROW
BEGIN
  DECLARE v_stock_restant INT;
  DECLARE v_seuil_alerte  INT;

  UPDATE produit
  SET stock = stock - NEW.quantite
  WHERE id_produit = NEW.id_produit;

  SELECT stock, seuil_alerte
  INTO v_stock_restant, v_seuil_alerte
  FROM produit
  WHERE id_produit = NEW.id_produit;

  IF v_stock_restant <= v_seuil_alerte THEN
    INSERT INTO alerte_stock (id_produit, stock_restant)
    VALUES (NEW.id_produit, v_stock_restant);
  END IF;
END$$

CREATE TRIGGER trg_produit_ai
AFTER INSERT ON produit
FOR EACH ROW
BEGIN
    INSERT INTO journal
    (utilisateur, table_cible, action, detail)
    VALUES
    (
        USER(),
        'produit',
        'INSERT',
        CONCAT('id=', NEW.id_produit, ' ; libelle=', NEW.libelle)
    );
END$$

CREATE TRIGGER trg_bug_client_ai
BEFORE INSERT ON client
FOR EACH ROW
BEGIN
  SET NEW.email = LOWER(NEW.email);
END$$

CREATE TRIGGER trg_bug_ligne_au
BEFORE UPDATE ON ligne_commande
FOR EACH ROW
BEGIN
  IF NEW.quantite > 100 THEN
    SET NEW.quantite = 100;
  END IF;
END$$

CREATE TRIGGER trg_bug_client_ad
AFTER DELETE ON client
FOR EACH ROW
BEGIN
  INSERT INTO journal (utilisateur, table_cible, action, detail)
  VALUES (USER(), 'client', 'DELETE', CONCAT('id=', OLD.id_client));
END$$

CREATE TRIGGER trg_bug_ligne_ad
AFTER DELETE ON ligne_commande
FOR EACH ROW
BEGIN
  UPDATE produit
  SET stock = stock + OLD.quantite
  WHERE id_produit = OLD.id_produit;
END$$

CREATE TRIGGER trg_commande_au
AFTER UPDATE ON commande
FOR EACH ROW
BEGIN
  -- Bloc 1 : annulation => on remet le stock
  IF OLD.statut <> 'ANNULEE' AND NEW.statut = 'ANNULEE' THEN
    UPDATE produit p
    JOIN (
      SELECT id_produit, SUM(quantite) AS quantite_totale
      FROM ligne_commande
      WHERE id_commande = NEW.id_commande
      GROUP BY id_produit
    ) l ON l.id_produit = p.id_produit
    SET p.stock = p.stock + l.quantite_totale;
  END IF;

  -- Bloc 2 : validation => ajouter le montant au cumul du client
  IF OLD.statut = 'EN_COURS' AND NEW.statut = 'VALIDEE' THEN
    UPDATE client
    SET total_achats = total_achats + (
      SELECT COALESCE(SUM(quantite * prix_unitaire), 0)
      FROM ligne_commande
      WHERE id_commande = NEW.id_commande
    )
    WHERE id_client = NEW.id_client;
  END IF;
END$$

DELIMITER ;
