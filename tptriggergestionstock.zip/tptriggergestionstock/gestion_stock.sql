-- Identite : Fadi Alouani
-- N = 7 ; M = 9 ; initiale = F

DROP DATABASE IF EXISTS tp_triggers;
CREATE DATABASE tp_triggers CHARACTER SET utf8mb4;
USE tp_triggers;

CREATE TABLE produit (
  id_produit   INT AUTO_INCREMENT PRIMARY KEY,
  libelle      VARCHAR(80)  NOT NULL,
  prix_ht      DECIMAL(8,2) NOT NULL,
  stock        INT          NOT NULL DEFAULT 0,
  seuil_alerte INT          NOT NULL DEFAULT 5
);

CREATE TABLE client (
  id_client    INT AUTO_INCREMENT PRIMARY KEY,
  nom          VARCHAR(60)  NOT NULL,
  email        VARCHAR(100) NOT NULL,
  total_achats DECIMAL(10,2) NOT NULL DEFAULT 0
);

CREATE TABLE commande (
  id_commande   INT AUTO_INCREMENT PRIMARY KEY,
  id_client     INT NOT NULL,
  date_commande DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  statut        ENUM('EN_COURS','VALIDEE','ANNULEE') NOT NULL DEFAULT 'EN_COURS',
  FOREIGN KEY (id_client) REFERENCES client(id_client)
);

CREATE TABLE ligne_commande (
  id_ligne      INT AUTO_INCREMENT PRIMARY KEY,
  id_commande   INT NOT NULL,
  id_produit    INT NOT NULL,
  quantite      INT NOT NULL,
  prix_unitaire DECIMAL(8,2) NULL,
  FOREIGN KEY (id_commande) REFERENCES commande(id_commande),
  FOREIGN KEY (id_produit)  REFERENCES produit(id_produit)
);

CREATE TABLE journal (
  id_journal  INT AUTO_INCREMENT PRIMARY KEY,
  date_evt    DATETIME DEFAULT CURRENT_TIMESTAMP,
  utilisateur VARCHAR(100),
  table_cible VARCHAR(40),
  action      VARCHAR(10),
  detail      VARCHAR(255)
);

CREATE TABLE historique_prix (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  id_produit   INT NOT NULL,
  ancien_prix  DECIMAL(8,2),
  nouveau_prix DECIMAL(8,2),
  date_modif   DATETIME DEFAULT CURRENT_TIMESTAMP,
  utilisateur  VARCHAR(100)
);

CREATE TABLE alerte_stock (
  id_alerte     INT AUTO_INCREMENT PRIMARY KEY,
  id_produit    INT NOT NULL,
  stock_restant INT NOT NULL,
  date_alerte   DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO produit (libelle, prix_ht, stock, seuil_alerte) VALUES
('Clavier mécanique', 59.90, 25, 5),
('Souris sans fil',   24.50, 40, 8),
('Écran 24 pouces',  139.00, 12, 3),
('Câble HDMI 2 m',     9.90, 60, 10),
('Casque audio',      79.00, 15, 4),
('Webcam HD',         34.90,  8, 2);

INSERT INTO client (nom, email) VALUES
('Martin',  'martin@exemple.fr'),
('Durand',  'durand@exemple.fr'),
('Lefèvre', 'lefevre@exemple.fr'),
('Moreau',  'moreau@exemple.fr');



DELIMITER $$

CREATE TRIGGER trg_produit_au
AFTER UPDATE ON produit
FOR EACH ROW
BEGIN

  -- Si le prix a changé, on garde son historique
  IF NOT (OLD.prix_ht <=> NEW.prix_ht) THEN

    INSERT INTO historique_prix
    (id_produit, ancien_prix, nouveau_prix, utilisateur)
    VALUES
    (NEW.id_produit, OLD.prix_ht, NEW.prix_ht, USER());

  END IF;

  -- Si le stock a changé, on écrit dans le journal
  IF NOT (OLD.stock <=> NEW.stock) THEN

    INSERT INTO journal
    (utilisateur, table_cible, action, detail)
    VALUES
    (USER(), 'produit', 'UPDATE',
     CONCAT('stock ', OLD.stock, ' -> ', NEW.stock));

  END IF;

END$$

DELIMITER ;





DELIMITER $$

CREATE TRIGGER trg_produit_ad
AFTER DELETE ON produit
FOR EACH ROW
BEGIN

  INSERT INTO journal
  (utilisateur, table_cible, action, detail)
  VALUES
  (USER(), 'produit', 'DELETE',
   CONCAT('id=', OLD.id_produit, ' ; libelle=', OLD.libelle));

END$$

DELIMITER ;




DELIMITER $$

CREATE TRIGGER trg_produit_bi
BEFORE INSERT ON produit
FOR EACH ROW
BEGIN

  -- Supprimer les espaces inutiles
  SET NEW.libelle = TRIM(NEW.libelle);

  -- Vérifier que le libellé n'est pas vide
  IF NEW.libelle = '' THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Libellé obligatoire';
  END IF;

  -- Refuser un prix inférieur ou égal à 0
  IF NEW.prix_ht <= 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Prix invalide';
  END IF;

  -- Refuser un stock négatif
  IF NEW.stock < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Stock négatif interdit';
  END IF;

END$$

DELIMITER ;



DELIMITER $$

CREATE TRIGGER trg_produit_bu
BEFORE UPDATE ON produit
FOR EACH ROW
BEGIN

  -- Nettoyer le libellé
  SET NEW.libelle = TRIM(NEW.libelle);

  -- Vérifier le libellé
  IF NEW.libelle = '' THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Libellé obligatoire à la modification';
  END IF;

  -- Vérifier le prix
  IF NEW.prix_ht <= 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Prix invalide à la modification';
  END IF;

  -- Vérifier le stock
  IF NEW.stock < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Stock négatif interdit à la modification';
  END IF;

  -- Initiale F : interdire une baisse de prix superieure a 30 %
  IF NEW.prix_ht < OLD.prix_ht * 0.70 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Baisse de prix superieure a 30 % interdite';
  END IF;

END$$

DELIMITER ;




DELIMITER $$
CREATE TRIGGER trg_ligne_bi
BEFORE INSERT ON ligne_commande
FOR EACH ROW
BEGIN
  DECLARE v_stock INT;
  DECLARE v_prix  DECIMAL(8,2);

  SELECT stock, prix_ht INTO v_stock, v_prix
  FROM produit
  WHERE id_produit = NEW.id_produit;

  IF NEW.quantite <= 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Quantité invalide';
  END IF;

  IF v_stock < NEW.quantite THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock insuffisant';
  END IF;

  SET NEW.prix_unitaire = v_prix;
END$$
DELIMITER ;


DELIMITER $$

CREATE TRIGGER trg_ligne_ai
AFTER INSERT ON ligne_commande
FOR EACH ROW
BEGIN
  DECLARE v_stock_restant INT;
  DECLARE v_seuil_alerte  INT;

  UPDATE produit
  SET stock = stock - NEW.quantite
  WHERE id_produit = NEW.id_produit;

  SELECT stock, seuil_alerte
  INTO v_stock_restant, v_seuil_alerte
  FROM produit
  WHERE id_produit = NEW.id_produit;

  IF v_stock_restant <= v_seuil_alerte THEN
    INSERT INTO alerte_stock (id_produit, stock_restant)
    VALUES (NEW.id_produit, v_stock_restant);
  END IF;
END$$

DELIMITER ;


DELIMITER $$

CREATE TRIGGER trg_produit_ai
AFTER INSERT ON produit
FOR EACH ROW
BEGIN
    INSERT INTO journal
    (utilisateur, table_cible, action, detail)
    VALUES
    (
        USER(),
        'produit',
        'INSERT',
        CONCAT('id=', NEW.id_produit, ' ; libelle=', NEW.libelle)
    );
END$$

DELIMITER ;


DELIMITER $$

-- Anomalie 1
CREATE TRIGGER trg_bug_client_ai
BEFORE INSERT ON client
FOR EACH ROW
BEGIN
  SET NEW.email = LOWER(NEW.email);
END$$

-- Anomalie 2
CREATE TRIGGER trg_bug_ligne_au
BEFORE UPDATE ON ligne_commande
FOR EACH ROW
BEGIN
  IF NEW.quantite > 100 THEN
    SET NEW.quantite = 100;
  END IF;
END$$

-- Anomalie 3
CREATE TRIGGER trg_bug_client_ad
AFTER DELETE ON client
FOR EACH ROW
BEGIN
  INSERT INTO journal (utilisateur, table_cible, action, detail)
  VALUES (USER(), 'client', 'DELETE', CONCAT('id=', OLD.id_client));
END$$

-- Anomalie 4
CREATE TRIGGER trg_bug_ligne_ad
AFTER DELETE ON ligne_commande
FOR EACH ROW
BEGIN
  UPDATE produit
  SET stock = stock + OLD.quantite
  WHERE id_produit = OLD.id_produit;
END$$

DELIMITER ;


DELIMITER $$
CREATE TRIGGER trg_commande_au
AFTER UPDATE ON commande
FOR EACH ROW
BEGIN
  -- Bloc 1 : annulation => on remet le stock
  IF OLD.statut <> 'ANNULEE' AND NEW.statut = 'ANNULEE' THEN
    UPDATE produit p
    JOIN (
      SELECT id_produit, SUM(quantite) AS quantite_totale
      FROM ligne_commande
      WHERE id_commande = NEW.id_commande
      GROUP BY id_produit
    ) l ON l.id_produit = p.id_produit
    SET p.stock = p.stock + l.quantite_totale;
  END IF;

  -- Bloc 2 : validation => ajouter le montant au cumul du client
  IF OLD.statut = 'EN_COURS' AND NEW.statut = 'VALIDEE' THEN
    UPDATE client
    SET total_achats = total_achats + (
      SELECT COALESCE(SUM(quantite * prix_unitaire), 0)
      FROM ligne_commande
      WHERE id_commande = NEW.id_commande
    )
    WHERE id_client = NEW.id_client;
  END IF;
END$$
DELIMITER ;