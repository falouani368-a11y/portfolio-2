<?php

class Voiture
{
    private $marque;
    private $couleur;
    private $immatriculation;

    // Getter pour la marque
    public function getMarque()
    {
        return $this->marque;
    }

    // Setter pour la marque
    public function setMarque($marque2)
    {
        $this->marque = $marque2;
    }

    // Getter pour la couleur
    public function getCouleur()
    {
        return $this->couleur;
    }

    // Setter pour la couleur
    public function setCouleur($couleur2)
    {
        $this->couleur = $couleur2;
    }

    // Getter pour l'immatriculation
    public function getImmatriculation()
    {
        return $this->immatriculation;
    }

    // Setter pour l'immatriculation
    public function setImmatriculation($immatriculation2)
    {
        if (strlen($immatriculation2) <= 8) {
            $this->immatriculation = $immatriculation2;
        }
    }

    // Constructeur
    public function __construct($m, $c, $i)
    {
        $this->marque = $m;
        $this->couleur = $c;
        $this->immatriculation = $i;
    }

    // Méthode d'affichage
    public function afficher()
    {
        echo "<p>Voiture " . $this->immatriculation
           . " de marque " . $this->marque
           . " (couleur " . $this->couleur . ")</p>";
    }
}

?>
