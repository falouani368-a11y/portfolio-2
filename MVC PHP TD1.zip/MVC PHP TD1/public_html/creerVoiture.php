<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Création voiture</title>
</head>
<body>

<?php

$immatriculation = $_POST["immatriculation"];
$marque = $_POST["marque"];
$couleur = $_POST["couleur"];

?>

<p>
    Voiture <?php echo $immatriculation; ?>
    de marque <?php echo $marque; ?>
    (couleur <?php echo $couleur; ?>)
</p>

</body>
</html>
