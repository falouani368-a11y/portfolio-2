<?php

class Trajet
{
    private $id;
    private $depart;
    private $arrivee;
    private $date;
    private $nbplaces;
    private $prix;
    private $conducteur_login;

    public function get($nom_attribut)
    {
        return $this->$nom_attribut;
    }

    public function set($nom_attribut, $valeur)
    {
        $this->$nom_attribut = $valeur;
    }

    public function __construct($data)
    {
        foreach ($data as $attribut => $valeur) {
            $this->$attribut = $valeur;
        }
    }
}

?>
