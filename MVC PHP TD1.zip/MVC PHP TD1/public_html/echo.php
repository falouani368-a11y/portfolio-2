<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Mon premier PHP</title>
</head>
<body>

Voici le résultat du script PHP :

<?php

// 1. Création des variables
$marque = "Renault";
$couleur = "bleu";
$immatriculation = "256AB34";

// Affichage des variables
echo "<p>Voiture " . $immatriculation . " de marque " . $marque . " (couleur " . $couleur . ")</p>";


// 2. Création d'un tableau associatif
$voiture = array(
    "marque" => "Peugeot",
    "couleur" => "rouge",
    "immatriculation" => "123CD45"
);

// Vérification du contenu du tableau
var_dump($voiture);

// Affichage du tableau
echo "<p>Voiture " . $voiture["immatriculation"] .
     " de marque " . $voiture["marque"] .
     " (couleur " . $voiture["couleur"] . ")</p>";


// 3. Création d'une liste de voitures
$voitures = array(
    array(
        "marque" => "Renault",
        "couleur" => "bleu",
        "immatriculation" => "256AB34"
    ),
    array(
        "marque" => "Peugeot",
        "couleur" => "rouge",
        "immatriculation" => "123CD45"
    ),
    array(
        "marque" => "BMW",
        "couleur" => "noir",
        "immatriculation" => "789EF67"
    )
);

// Vérification du contenu du tableau
var_dump($voitures);


// 4. Affichage de la liste
if (empty($voitures)) {
    echo "<p>Il n'y a aucune voiture.</p>";
} else {
    echo "<h2>Liste des voitures :</h2>";
    echo "<ul>";

    foreach ($voitures as $voiture) {
        echo "<li>Voiture " . $voiture["immatriculation"] .
             " de marque " . $voiture["marque"] .
             " (couleur " . $voiture["couleur"] . ")</li>";
    }

    echo "</ul>";
}

?>

</body>
</html>
