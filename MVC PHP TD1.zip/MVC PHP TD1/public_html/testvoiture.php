<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Test de la classe Voiture</title>
</head>
<body>

<?php

// Inclusion de la classe Voiture
require_once "Voiture.php";

// Création d'un objet Voiture
$voiture1 = new Voiture("Renault", "bleu", "256AB34");

// Affichage de la voiture
$voiture1->afficher();

?>

</body>
</html>
