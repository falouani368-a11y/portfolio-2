<?php

class Utilisateur
{
    private $login;
    private $nom;
    private $prenom;

    public function get($nom_attribut)
    {
        return $this->$nom_attribut;
    }

    public function set($nom_attribut, $valeur)
    {
        $this->$nom_attribut = $valeur;
    }

    public function __construct($data)
    {
        foreach ($data as $attribut => $valeur) {
            $this->$attribut = $valeur;
        }
    }
}

?>
