import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'firebase_options.dart';

// ============================================================
// FIREBASE
// ============================================================

final FirebaseAuth auth = FirebaseAuth.instance;
final FirebaseStorage storage = FirebaseStorage.instance;

// ============================================================
// MAIN
// ============================================================

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(const MyApp());
}

// ============================================================
// APPLICATION
// ============================================================

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TP Firebase',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const AuthPage(),
    );
  }
}

// ============================================================
// AUTH PAGE
// ============================================================

class AuthPage extends StatelessWidget {
  const AuthPage({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: auth.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasData) {
          return const ProfilPage();
        }

        return const LoginPage();
      },
    );
  }
}

// ============================================================
// LOGIN
// ============================================================

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();

  final TextEditingController passwordController = TextEditingController();

  bool loading = false;

  Future<void> login() async {
    final email = emailController.text.trim();
    final password = passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      showMessage('Veuillez remplir tous les champs.');
      return;
    }

    setState(() {
      loading = true;
    });

    try {
      await auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      String message;

      switch (e.code) {
        case 'invalid-credential':
          message = 'Email ou mot de passe incorrect.';
          break;
        case 'user-not-found':
          message = 'Utilisateur introuvable.';
          break;
        case 'wrong-password':
          message = 'Mot de passe incorrect.';
          break;
        case 'invalid-email':
          message = 'Adresse email invalide.';
          break;
        default:
          message = e.message ?? 'Erreur de connexion.';
      }

      showMessage(message);
    } catch (e) {
      showMessage('Erreur : $e');
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Connexion Firebase')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.account_circle, size: 100, color: Colors.blue),

                const SizedBox(height: 30),

                TextField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Adresse email',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email),
                  ),
                ),

                const SizedBox(height: 15),

                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Mot de passe',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.lock),
                  ),
                ),

                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: loading ? null : login,
                    child: loading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('CONNEXION'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}

// ============================================================
// PROFIL
// ============================================================

class ProfilPage extends StatefulWidget {
  const ProfilPage({super.key});

  @override
  State<ProfilPage> createState() => _ProfilPageState();
}

class _ProfilPageState extends State<ProfilPage> {
  final ImagePicker picker = ImagePicker();

  XFile? selectedImage;
  Uint8List? selectedImageBytes;

  bool uploading = false;

  User? get currentUser => auth.currentUser;

  // ==========================================================
  // CHOISIR UNE IMAGE
  // ==========================================================

  Future<void> getImage() async {
    try {
      final XFile? file = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (file == null) {
        return;
      }

      final bytes = await file.readAsBytes();

      if (!mounted) {
        return;
      }

      setState(() {
        selectedImage = file;
        selectedImageBytes = bytes;
      });
    } catch (e) {
      showMessage('Erreur lors du choix de la photo : $e');
    }
  }

  // ==========================================================
  // ENVOYER LA PHOTO
  // ==========================================================

  Future<void> uploadFile() async {
    if (selectedImageBytes == null) {
      showMessage('Veuillez choisir une photo.');
      return;
    }

    final user = currentUser;

    if (user == null) {
      showMessage('Aucun utilisateur connecté.');
      return;
    }

    setState(() {
      uploading = true;
    });

    try {
      final String userID = user.uid;

      final Reference storageRef = storage
          .ref()
          .child('Users')
          .child('$userID.png');

      await storageRef.putData(
        selectedImageBytes!,
        SettableMetadata(contentType: 'image/jpeg'),
      );

      if (!mounted) {
        return;
      }

      showMessage('Photo de profil envoyée dans Firebase !');

      setState(() {
        selectedImage = null;
        selectedImageBytes = null;
      });
    } on FirebaseException catch (e) {
      showMessage('Erreur Firebase : ${e.message ?? e.code}');
    } catch (e) {
      showMessage('Erreur : $e');
    } finally {
      if (mounted) {
        setState(() {
          uploading = false;
        });
      }
    }
  }

  // ==========================================================
  // DECONNEXION
  // ==========================================================

  Future<void> logout() async {
    await auth.signOut();
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void showMessage(String message) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  // ==========================================================
  // INTERFACE
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    final user = currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Page de profil'),
        actions: [
          IconButton(
            onPressed: logout,
            icon: const Icon(Icons.logout),
            tooltip: 'Déconnexion',
          ),
        ],
      ),

      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),

          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),

            child: Column(
              children: [
                const SizedBox(height: 20),

                ProfileImage(refreshKey: uploading),

                const SizedBox(height: 25),

                Text(
                  user?.email ?? 'Aucun email',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  'ID : ${user?.uid ?? ''}',
                  style: const TextStyle(color: Colors.grey),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 30),

                if (selectedImageBytes != null) ...[
                  const Text(
                    'Nouvelle photo :',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 10),

                  CircleAvatar(
                    radius: 70,
                    backgroundImage: MemoryImage(selectedImageBytes!),
                  ),

                  const SizedBox(height: 20),
                ],

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: uploading ? null : getImage,
                    icon: const Icon(Icons.photo_library),
                    label: const Text('Choisir une photo'),
                  ),
                ),

                const SizedBox(height: 10),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: uploading ? null : uploadFile,
                    icon: uploading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.cloud_upload),
                    label: Text(
                      uploading ? 'Envoi en cours...' : 'Envoyer dans Firebase',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// PHOTO DE PROFIL DEPUIS FIREBASE STORAGE
// ============================================================

class ProfileImage extends StatefulWidget {
  final bool refreshKey;

  const ProfileImage({super.key, required this.refreshKey});

  @override
  State<ProfileImage> createState() => _ProfileImageState();
}

class _ProfileImageState extends State<ProfileImage> {
  String? userPhotoUrl;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    getProfileImage();
  }

  @override
  void didUpdateWidget(covariant ProfileImage oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.refreshKey != widget.refreshKey) {
      getProfileImage();
    }
  }

  // ==========================================================
  // RECUPERER LA PHOTO
  // ==========================================================

  Future<void> getProfileImage() async {
    final user = auth.currentUser;

    if (user == null) {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
      return;
    }

    if (mounted) {
      setState(() {
        loading = true;
      });
    }

    try {
      final Reference ref = storage
          .ref()
          .child('Users')
          .child('${user.uid}.png');

      final String downloadUrl = await ref.getDownloadURL();

      if (!mounted) {
        return;
      }

      setState(() {
        userPhotoUrl = downloadUrl;
        loading = false;
      });
    } catch (_) {
      if (!mounted) {
        return;
      }

      setState(() {
        userPhotoUrl = null;
        loading = false;
      });
    }
  }

  // ==========================================================
  // AFFICHAGE
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const CircleAvatar(
        radius: 100,
        child: CircularProgressIndicator(),
      );
    }

    if (userPhotoUrl == null) {
      return const CircleAvatar(
        radius: 100,
        backgroundColor: Colors.grey,
        child: Icon(Icons.person, size: 100, color: Colors.white),
      );
    }

    return CircleAvatar(
      radius: 100,
      backgroundImage: NetworkImage(userPhotoUrl!),
    );
  }
}
