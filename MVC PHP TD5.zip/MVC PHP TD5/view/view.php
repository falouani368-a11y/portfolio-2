<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title><?php echo $pagetitle; ?></title>
</head>

<body>

<nav>
    <a href="/MVC%20PHP%20TD5/index.php?action=readAll">
        Voitures
    </a>

    <a href="/MVC%20PHP%20TD5/index.php?action=readAll&controller=utilisateur">
        Utilisateurs
    </a>

    <a href="/MVC%20PHP%20TD5/index.php?action=readAll&controller=trajet">
        Trajets
    </a>
</nav>

<hr>

<?php

$filepath = File::build_path(array("view", $controller, "$view.php"));

require $filepath;

?>

<hr>

<p style="border: 1px solid black; text-align:right; padding-right:1em;">
    Site de covoiturage
</p>

</body>

</html>
