<h1>Liste des voitures</h1>

<?php

foreach ($tab_v as $v) {

    echo '<p>';

    echo 'Immatriculation : ';

    echo '<a href="/MVC%20PHP%20TD5/controller/routeur.php?action=read&immat='
        . rawurlencode($v->getImmatriculation())
        . '">';

    echo htmlspecialchars($v->getImmatriculation());

    echo '</a>';

    echo ' | Marque : '
        . htmlspecialchars($v->getMarque());

    echo ' | Couleur : '
        . htmlspecialchars($v->getCouleur());

    echo '</p>';
}

?>

<p>
    <a href="/MVC%20PHP%20TD5/controller/routeur.php?action=create">
        Ajouter une voiture
    </a>
</p>
