<?php

require_once __DIR__ . '/../model/ModelVoiture.php';

class ControllerVoiture {

    // Afficher toutes les voitures
    public static function readAll() {

        $tab_v = ModelVoiture::getAllVoitures();

        $controller = "voiture";
        $view = "list";
        $pagetitle = "Liste des voitures";

        require __DIR__ . '/../view/view.php';
    }


    // Afficher le détail d'une voiture
    public static function read() {

        $immat = $_GET['immat'];

        $v = ModelVoiture::getVoitureByImmat($immat);

        if ($v == false) {

            $controller = "voiture";
            $view = "error";
            $pagetitle = "Erreur";

            require __DIR__ . '/../view/view.php';

        } else {

            $controller = "voiture";
            $view = "detail";
            $pagetitle = "Détail de la voiture";

            require __DIR__ . '/../view/view.php';
        }
    }


    // Afficher le formulaire de création
    public static function create() {

        $controller = "voiture";
        $view = "create";
        $pagetitle = "Ajouter une voiture";

        require __DIR__ . '/../view/view.php';
    }


    // Créer une voiture
    public static function created() {

        $immatriculation = $_GET['immatriculation'];
        $marque = $_GET['marque'];
        $couleur = $_GET['couleur'];

        $v = new ModelVoiture(
            $marque,
            $couleur,
            $immatriculation
        );

        $v->save();

        self::readAll();
    }
}

?>
