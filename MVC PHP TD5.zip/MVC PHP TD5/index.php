<?php

$DS = DIRECTORY_SEPARATOR;
$ROOT_FOLDER = __DIR__;

require_once $ROOT_FOLDER . $DS . "lib" . $DS . "File.php";
require_once $ROOT_FOLDER . $DS . "controller" . $DS . "routeur.php";

?>
