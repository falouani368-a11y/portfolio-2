<?php

class Conf {

    static $databases = array(
        'hostname' => 'localhost',
        'database' => 'garage',
        'login' => 'root',
        'password' => ''
    );

    public static function getHostname() {
        return self::$databases['hostname'];
    }

    public static function getDatabase() {
        return self::$databases['database'];
    }

    public static function getLogin() {
        return self::$databases['login'];
    }

    public static function getPassword() {
        return self::$databases['password'];
    }
}

?>
