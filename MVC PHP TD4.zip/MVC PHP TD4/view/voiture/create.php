<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Ajouter une voiture</title>
</head>

<body>

<h1>Ajouter une voiture</h1>

<form method="GET" action="/MVC%20PHP%20TD4/controller/routeur.php">

    <input type="hidden" name="action" value="created">

    <p>
        <label for="immatriculation">
            Immatriculation :
        </label>

        <input
            type="text"
            id="immatriculation"
            name="immatriculation"
            required
        >
    </p>

    <p>
        <label for="marque">
            Marque :
        </label>

        <input
            type="text"
            id="marque"
            name="marque"
            required
        >
    </p>

    <p>
        <label for="couleur">
            Couleur :
        </label>

        <input
            type="text"
            id="couleur"
            name="couleur"
            required
        >
    </p>

    <p>
        <input type="submit" value="Ajouter">
    </p>

</form>

<p>
    <a href="/MVC%20PHP%20TD4/controller/routeur.php?action=readAll">
        Retour à la liste
    </a>
</p>

</body>

</html>
