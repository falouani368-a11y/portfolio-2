<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Détail de la voiture</title>
</head>

<body>

<h1>Détail de la voiture</h1>

<p>
    <strong>Immatriculation :</strong>
    <?php echo htmlspecialchars($v->getImmatriculation()); ?>
</p>

<p>
    <strong>Marque :</strong>
    <?php echo htmlspecialchars($v->getMarque()); ?>
</p>

<p>
    <strong>Couleur :</strong>
    <?php echo htmlspecialchars($v->getCouleur()); ?>
</p>

<p>
    <a href="../../controller/routeur.php?action=readAll">
        Retour à la liste
    </a>
</p>

</body>

</html>
