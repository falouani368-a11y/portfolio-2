<?php

require_once __DIR__ . '/ControllerVoiture.php';

if (isset($_GET['action'])) {

    $action = $_GET['action'];

    if ($action == 'readAll') {
        ControllerVoiture::readAll();
    }

    elseif ($action == 'read') {
        ControllerVoiture::read();
    }

    elseif ($action == 'create') {
        ControllerVoiture::create();
    }

    elseif ($action == 'created') {
        ControllerVoiture::created();
    }

    else {
        echo "Action inconnue : " . htmlspecialchars($action);
    }

} else {

    ControllerVoiture::readAll();

}

?>
