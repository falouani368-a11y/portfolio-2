<?php

require_once __DIR__ . '/../model/ModelVoiture.php';

class ControllerVoiture {

    // Afficher toutes les voitures
    public static function readAll() {

        $tab_v = ModelVoiture::getAllVoitures();

        require __DIR__ . '/../view/voiture/list.php';
    }


    // Afficher le détail d'une voiture
    public static function read() {

        $immat = $_GET['immat'];

        $v = ModelVoiture::getVoitureByImmat($immat);

        if ($v == false) {

            require __DIR__ . '/../view/voiture/error.php';

        } else {

            require __DIR__ . '/../view/voiture/detail.php';
        }
    }


    // Afficher le formulaire de création
    public static function create() {

        require __DIR__ . '/../view/voiture/create.php';
    }


    // Créer une voiture
    public static function created() {

        $immatriculation = $_GET['immatriculation'];
        $marque = $_GET['marque'];
        $couleur = $_GET['couleur'];

        $v = new ModelVoiture(
            $marque,
            $couleur,
            $immatriculation
        );

        $v->save();

        self::readAll();
    }
}

?>
