<?php

require_once __DIR__ . '/Model.php';

class ModelVoiture {

    private $marque;
    private $couleur;
    private $immatriculation;


    public function __construct($m = NULL, $c = NULL, $i = NULL) {
        $this->marque = $m;
        $this->couleur = $c;
        $this->immatriculation = $i;
    }


    public function getMarque() {
        return $this->marque;
    }


    public function getCouleur() {
        return $this->couleur;
    }


    public function getImmatriculation() {
        return $this->immatriculation;
    }


    public function setMarque($m) {
        $this->marque = $m;
    }


    public function setCouleur($c) {
        $this->couleur = $c;
    }


    public function setImmatriculation($i) {
        $this->immatriculation = $i;
    }


    public static function getAllVoitures() {

        $sql = "SELECT immatriculation, marque, couleur
                FROM voiture";

        $pdo = Model::getPdo();

        $req_prep = $pdo->prepare($sql);
        $req_prep->execute();

        $resultats = $req_prep->fetchAll(PDO::FETCH_ASSOC);

        $tab_v = array();

        foreach ($resultats as $ligne) {

            $v = new ModelVoiture(
                $ligne['marque'],
                $ligne['couleur'],
                $ligne['immatriculation']
            );

            $tab_v[] = $v;
        }

        return $tab_v;
    }


    public static function getVoitureByImmat($immatriculation) {

        $sql = "SELECT immatriculation, marque, couleur
                FROM voiture
                WHERE immatriculation = :immatriculation";

        $pdo = Model::getPdo();

        $req_prep = $pdo->prepare($sql);

        $values = array(
            'immatriculation' => $immatriculation
        );

        $req_prep->execute($values);

        $ligne = $req_prep->fetch(PDO::FETCH_ASSOC);

        if ($ligne == false) {
            return false;
        }

        return new ModelVoiture(
            $ligne['marque'],
            $ligne['couleur'],
            $ligne['immatriculation']
        );
    }


    public function save() {

        $sql = "INSERT INTO voiture
                (immatriculation, marque, couleur)
                VALUES
                (:immatriculation, :marque, :couleur)";

        $pdo = Model::getPdo();

        $req_prep = $pdo->prepare($sql);

        $values = array(
            'immatriculation' => $this->immatriculation,
            'marque' => $this->marque,
            'couleur' => $this->couleur
        );

        $req_prep->execute($values);
    }
}

?>
