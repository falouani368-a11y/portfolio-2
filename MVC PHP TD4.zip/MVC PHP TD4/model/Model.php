<?php

require_once __DIR__ . '/../config/Conf.php';

class Model {

    private static $pdo = NULL;

    public static function getPdo() {

        if (is_null(self::$pdo)) {

            self::$pdo = new PDO(
                'mysql:host=' . Conf::getHostname()
                . ';dbname=' . Conf::getDatabase(),
                Conf::getLogin(),
                Conf::getPassword()
            );

            self::$pdo->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            self::$pdo->setAttribute(
                PDO::ATTR_DEFAULT_FETCH_MODE,
                PDO::FETCH_OBJ
            );
        }

        return self::$pdo;
    }
}

?>
