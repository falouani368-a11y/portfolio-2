<?php

require_once 'voiture.php';

$tab_voit = Voiture::getAllVoitures();

foreach ($tab_voit as $voit) {
    $voit->afficher();
    echo "<br>";
}

?>
