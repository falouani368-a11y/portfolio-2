<?php

require_once 'Model.php';

class Voiture {

    public $immatriculation;
    public $marque;
    public $couleur;

    public function afficher() {
        echo $this->immatriculation . " - ";
        echo $this->marque . " - ";
        echo $this->couleur;
    }

    public static function getAllVoitures() {
        $rep = Model::$pdo->query("SELECT * FROM voiture");

        $rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');

        return $rep->fetchAll();
    }
}

?>
