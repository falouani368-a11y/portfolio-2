<?php

require_once 'Conf.php';

class Model {

    public static $pdo;

    public static function Init() {

        $hostname = Conf::getHostname();
        $database_name = Conf::getDatabase();
        $login = Conf::getLogin();
        $password = Conf::getPassword();

        try {
            self::$pdo = new PDO(
                "mysql:host=$hostname;dbname=$database_name",
                $login,
                $password
            );

            self::$pdo->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

        } catch (PDOException $e) {
            echo $e->getMessage();
            die();
        }
    }
}

Model::Init();

?>
