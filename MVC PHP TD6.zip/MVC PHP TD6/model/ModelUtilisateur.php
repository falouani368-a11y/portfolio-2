<?php

require_once __DIR__ . '/Model.php';

class ModelUtilisateur extends Model {

    protected static $object = 'utilisateur';

    protected static $primary = 'login';


    private $login;
    private $nom;
    private $prenom;


    public function __construct(
        $login = null,
        $nom = null,
        $prenom = null
    ) {
        $this->login = $login;
        $this->nom = $nom;
        $this->prenom = $prenom;
    }


    // GETTERS

    public function getLogin() {
        return $this->login;
    }

    public function getNom() {
        return $this->nom;
    }

    public function getPrenom() {
        return $this->prenom;
    }


    // SETTERS

    public function setLogin($login) {
        $this->login = $login;
    }

    public function setNom($nom) {
        $this->nom = $nom;
    }

    public function setPrenom($prenom) {
        $this->prenom = $prenom;
    }
}

?>
