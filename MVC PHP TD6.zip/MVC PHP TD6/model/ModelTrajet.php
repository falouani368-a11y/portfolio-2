<?php

require_once __DIR__ . '/Model.php';

class ModelTrajet extends Model {

    protected static $object = 'trajet';

    protected static $primary = 'id';


    private $id;
    private $depart;
    private $arrivee;
    private $date;
    private $nbplaces;
    private $prix;
    private $conducteur_login;


    public function __construct(
        $id = null,
        $depart = null,
        $arrivee = null,
        $date = null,
        $nbplaces = null,
        $prix = null,
        $conducteur_login = null
    ) {
        $this->id = $id;
        $this->depart = $depart;
        $this->arrivee = $arrivee;
        $this->date = $date;
        $this->nbplaces = $nbplaces;
        $this->prix = $prix;
        $this->conducteur_login = $conducteur_login;
    }


    // GETTERS

    public function getId() {
        return $this->id;
    }

    public function getDepart() {
        return $this->depart;
    }

    public function getArrivee() {
        return $this->arrivee;
    }

    public function getDate() {
        return $this->date;
    }

    public function getNbplaces() {
        return $this->nbplaces;
    }

    public function getPrix() {
        return $this->prix;
    }

    public function getConducteurLogin() {
        return $this->conducteur_login;
    }


    // SETTERS

    public function setId($id) {
        $this->id = $id;
    }

    public function setDepart($depart) {
        $this->depart = $depart;
    }

    public function setArrivee($arrivee) {
        $this->arrivee = $arrivee;
    }

    public function setDate($date) {
        $this->date = $date;
    }

    public function setNbplaces($nbplaces) {
        $this->nbplaces = $nbplaces;
    }

    public function setPrix($prix) {
        $this->prix = $prix;
    }

    public function setConducteurLogin($conducteur_login) {
        $this->conducteur_login = $conducteur_login;
    }
}

?>
