<?php

require_once __DIR__ . '/Model.php';

class ModelVoiture extends Model {

    protected static $object = 'voiture';

    protected static $primary = 'immatriculation';


    private $immatriculation;
    private $marque;
    private $couleur;


    public function __construct(
        $immatriculation = null,
        $marque = null,
        $couleur = null
    ) {
        $this->immatriculation = $immatriculation;
        $this->marque = $marque;
        $this->couleur = $couleur;
    }


    // GETTERS

    public function getImmatriculation() {
        return $this->immatriculation;
    }

    public function getMarque() {
        return $this->marque;
    }

    public function getCouleur() {
        return $this->couleur;
    }


    // SETTERS

    public function setImmatriculation($immatriculation) {
        $this->immatriculation = $immatriculation;
    }

    public function setMarque($marque) {
        $this->marque = $marque;
    }

    public function setCouleur($couleur) {
        $this->couleur = $couleur;
    }
}

?>
