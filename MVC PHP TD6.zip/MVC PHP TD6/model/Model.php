<?php

require_once __DIR__ . '/../conf/Conf.php';

class Model {

    protected static $pdo = null;


    // --------------------------------------------------
    // CONNEXION A LA BDD
    // --------------------------------------------------

    public static function init_pdo() {

        if (self::$pdo === null) {

            $hostname = Conf::getHostname();
            $database = Conf::getDatabase();
            $login = Conf::getLogin();
            $password = Conf::getPassword();

            self::$pdo = new PDO(
                "mysql:host=" . $hostname . ";dbname=" . $database . ";charset=utf8",
                $login,
                $password
            );

            self::$pdo->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );
        }

        return self::$pdo;
    }


    // --------------------------------------------------
    // SELECT ALL
    // --------------------------------------------------

    public static function selectAll() {

        $pdo = self::init_pdo();

        $table_name = static::$object;

        $class_name = 'Model' . ucfirst($table_name);

        $sql = "SELECT * FROM " . $table_name;

        $req = $pdo->query($sql);

        /*
         * FETCH_PROPS_LATE permet de remplir les propriétés
         * avec les données de la BDD après l'appel du constructeur.
         */
        $req->setFetchMode(
            PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
            $class_name
        );

        return $req->fetchAll();
    }


    // --------------------------------------------------
    // SELECT PAR CLE PRIMAIRE
    // --------------------------------------------------

    public static function select($primary_value) {

        $pdo = self::init_pdo();

        $table_name = static::$object;

        $class_name = 'Model' . ucfirst($table_name);

        $primary_key = static::$primary;

        $sql = "SELECT *
                FROM " . $table_name . "
                WHERE " . $primary_key . " = :primary_value";

        $req = $pdo->prepare($sql);

        $req->execute(
            array(
                'primary_value' => $primary_value
            )
        );

        /*
         * Même correction que dans selectAll().
         */
        $req->setFetchMode(
            PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
            $class_name
        );

        return $req->fetch();
    }


    // --------------------------------------------------
    // DELETE
    // --------------------------------------------------

    public static function delete($primary_value) {

        $pdo = self::init_pdo();

        $table_name = static::$object;

        $primary_key = static::$primary;

        $sql = "DELETE FROM "
             . $table_name
             . " WHERE "
             . $primary_key
             . " = :primary_value";

        $req = $pdo->prepare($sql);

        $req->execute(
            array(
                'primary_value' => $primary_value
            )
        );
    }


    // --------------------------------------------------
    // SAVE
    // --------------------------------------------------

    public static function save($data) {

        $pdo = self::init_pdo();

        $table_name = static::$object;

        $columns = "";
        $values = "";

        foreach ($data as $key => $value) {

            $columns .= $key . ",";
            $values .= ":" . $key . ",";
        }

        $columns = rtrim($columns, ",");
        $values = rtrim($values, ",");

        $sql = "INSERT INTO "
             . $table_name
             . " ("
             . $columns
             . ") VALUES ("
             . $values
             . ")";

        $req = $pdo->prepare($sql);

        $req->execute($data);
    }


    // --------------------------------------------------
    // UPDATE
    // --------------------------------------------------

    public static function update($data) {

        $pdo = self::init_pdo();

        $table_name = static::$object;

        $primary_key = static::$primary;

        $set = "";

        foreach ($data as $key => $value) {

            $set .= $key . " = :" . $key . ",";
        }

        $set = rtrim($set, ",");

        $sql = "UPDATE "
             . $table_name
             . " SET "
             . $set
             . " WHERE "
             . $primary_key
             . " = :where_primary";

        $req = $pdo->prepare($sql);

        $values = $data;

        $values['where_primary'] = $data[$primary_key];

        $req->execute($values);
    }
}


// --------------------------------------------------
// INITIALISATION DE LA CONNEXION
// --------------------------------------------------

Model::init_pdo();

?>
