<h2>Utilisateur modifié</h2>

<p>

    L'utilisateur

    <strong>
        <?php echo htmlspecialchars($login); ?>
    </strong>

    a bien été mis à jour.

</p>


<?php require __DIR__ . '/list.php'; ?>
