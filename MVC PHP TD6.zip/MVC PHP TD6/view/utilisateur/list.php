<h2>Liste des utilisateurs</h2>


<p>

    <a href="index.php?controller=utilisateur&action=create">
        Ajouter un utilisateur
    </a>

</p>


<?php if (empty($tab_u)): ?>

    <p>
        Aucun utilisateur.
    </p>

<?php else: ?>

    <table border="1">

        <tr>

            <th>Login</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Actions</th>

        </tr>


        <?php foreach ($tab_u as $u): ?>

            <tr>

                <td>
                    <?php echo htmlspecialchars($u->getLogin()); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($u->getNom()); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($u->getPrenom()); ?>
                </td>

                <td>

                    <a href="index.php?controller=utilisateur&action=read&primary_value=<?php
                        echo rawurlencode($u->getLogin());
                    ?>">
                        Détails
                    </a>

                    |

                    <a href="index.php?controller=utilisateur&action=update&primary_value=<?php
                        echo rawurlencode($u->getLogin());
                    ?>">
                        Modifier
                    </a>

                    |

                    <a
                        href="index.php?controller=utilisateur&action=delete&primary_value=<?php
                            echo rawurlencode($u->getLogin());
                        ?>"
                        onclick="return confirm('Voulez-vous vraiment supprimer cet utilisateur ?');"
                    >
                        Supprimer
                    </a>

                </td>

            </tr>

        <?php endforeach; ?>

    </table>

<?php endif; ?>
