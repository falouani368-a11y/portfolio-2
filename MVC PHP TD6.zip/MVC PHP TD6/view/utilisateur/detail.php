<h2>Détail de l'utilisateur</h2>


<p>

    <strong>Login :</strong>

    <?php echo htmlspecialchars($u->getLogin()); ?>

</p>


<p>

    <strong>Nom :</strong>

    <?php echo htmlspecialchars($u->getNom()); ?>

</p>


<p>

    <strong>Prénom :</strong>

    <?php echo htmlspecialchars($u->getPrenom()); ?>

</p>


<p>

    <a href="index.php?controller=utilisateur&action=update&primary_value=<?php
        echo rawurlencode($u->getLogin());
    ?>">
        Modifier
    </a>

    |

    <a
        href="index.php?controller=utilisateur&action=delete&primary_value=<?php
            echo rawurlencode($u->getLogin());
        ?>"
        onclick="return confirm('Voulez-vous vraiment supprimer cet utilisateur ?');"
    >
        Supprimer
    </a>

</p>


<p>

    <a href="index.php?controller=utilisateur&action=readAll">
        Retour à la liste
    </a>

</p>
