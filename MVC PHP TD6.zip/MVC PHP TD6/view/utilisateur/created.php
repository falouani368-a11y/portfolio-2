<h2>Utilisateur créé</h2>

<p>

    L'utilisateur

    <strong>
        <?php echo htmlspecialchars($login); ?>
    </strong>

    a bien été créé.

</p>


<?php require __DIR__ . '/list.php'; ?>
