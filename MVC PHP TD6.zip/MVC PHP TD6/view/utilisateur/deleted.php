<h2>Utilisateur supprimé</h2>

<p>

    L'utilisateur

    <strong>
        <?php echo htmlspecialchars($login); ?>
    </strong>

    a bien été supprimé.

</p>


<?php require __DIR__ . '/list.php'; ?>
