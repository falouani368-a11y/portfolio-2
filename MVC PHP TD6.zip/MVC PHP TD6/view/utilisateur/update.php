<h2>

    <?php

    if ($action == 'save') {
        echo "Ajouter un utilisateur";
    } else {
        echo "Modifier un utilisateur";
    }

    ?>

</h2>


<form method="post" action="index.php">


    <input
        type="hidden"
        name="controller"
        value="utilisateur"
    >


    <input
        type="hidden"
        name="action"
        value="<?php echo htmlspecialchars($action); ?>"
    >


    <p>

        <label for="login">
            Login :
        </label>

        <input
            type="text"
            id="login"
            name="login"
            value="<?php echo htmlspecialchars($login); ?>"
            <?php echo $readonly; ?>
            <?php echo $required; ?>
        >

    </p>


    <p>

        <label for="nom">
            Nom :
        </label>

        <input
            type="text"
            id="nom"
            name="nom"
            value="<?php echo htmlspecialchars($nom); ?>"
            required
        >

    </p>


    <p>

        <label for="prenom">
            Prénom :
        </label>

        <input
            type="text"
            id="prenom"
            name="prenom"
            value="<?php echo htmlspecialchars($prenom); ?>"
            required
        >

    </p>


    <p>

        <input
            type="submit"
            value="<?php
                echo ($action == 'save')
                    ? 'Ajouter'
                    : 'Modifier';
            ?>"
        >

    </p>

</form>
