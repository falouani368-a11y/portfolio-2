<h2>Erreur</h2>

<p>
    L'utilisateur demandé n'existe pas ou l'action demandée est incorrecte.
</p>


<p>

    <a href="index.php?controller=utilisateur&action=readAll">
        Retour aux utilisateurs
    </a>

</p>
