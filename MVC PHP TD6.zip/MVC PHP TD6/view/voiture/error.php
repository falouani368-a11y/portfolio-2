<h2>Erreur</h2>

<p>
    La voiture demandée n'existe pas ou l'action demandée est incorrecte.
</p>


<p>

    <a href="index.php?controller=voiture&action=readAll">
        Retour aux voitures
    </a>

</p>
