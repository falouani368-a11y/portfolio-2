<h2>Voiture supprimée</h2>

<p>

    La voiture d'immatriculation

    <strong>
        <?php echo htmlspecialchars($immat); ?>
    </strong>

    a bien été supprimée.

</p>


<?php require __DIR__ . '/list.php'; ?>
