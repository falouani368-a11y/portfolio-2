<h2>Voiture modifiée</h2>

<p>

    La voiture d'immatriculation

    <strong>
        <?php echo htmlspecialchars($immat); ?>
    </strong>

    a bien été mise à jour.

</p>


<?php require __DIR__ . '/list.php'; ?>
