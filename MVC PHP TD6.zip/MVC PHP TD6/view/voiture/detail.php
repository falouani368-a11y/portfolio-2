<h2>Détail de la voiture</h2>


<p>
    <strong>Immatriculation :</strong>

    <?php echo htmlspecialchars($v->getImmatriculation()); ?>
</p>


<p>
    <strong>Marque :</strong>

    <?php echo htmlspecialchars($v->getMarque()); ?>
</p>


<p>
    <strong>Couleur :</strong>

    <?php echo htmlspecialchars($v->getCouleur()); ?>
</p>


<p>

    <a href="index.php?controller=voiture&action=update&primary_value=<?php
        echo rawurlencode($v->getImmatriculation());
    ?>">
        Modifier
    </a>

    |

    <a
        href="index.php?controller=voiture&action=delete&primary_value=<?php
            echo rawurlencode($v->getImmatriculation());
        ?>"
        onclick="return confirm('Voulez-vous vraiment supprimer cette voiture ?');"
    >
        Supprimer
    </a>

</p>


<p>

    <a href="index.php?controller=voiture&action=readAll">
        Retour à la liste
    </a>

</p>
