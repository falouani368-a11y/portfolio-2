<h2>Ajouter une voiture</h2>

<form method="get" action="index.php">

    <input
        type="hidden"
        name="action"
        value="created"
    >


    <p>

        <label for="immatriculation">
            Immatriculation :
        </label>

        <input
            type="text"
            id="immatriculation"
            name="immatriculation"
            required
        >

    </p>


    <p>

        <label for="marque">
            Marque :
        </label>

        <input
            type="text"
            id="marque"
            name="marque"
            required
        >

    </p>


    <p>

        <label for="couleur">
            Couleur :
        </label>

        <input
            type="text"
            id="couleur"
            name="couleur"
            required
        >

    </p>


    <p>

        <input
            type="submit"
            value="Ajouter"
        >

    </p>

</form>
