<h2>Voiture créée</h2>

<p>

    La voiture d'immatriculation

    <strong>
        <?php echo htmlspecialchars($immat); ?>
    </strong>

    a bien été créée.

</p>


<?php require __DIR__ . '/list.php'; ?>
