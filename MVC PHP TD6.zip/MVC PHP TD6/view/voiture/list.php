<h2>Liste des voitures</h2>

<p>
    <a href="index.php?controller=voiture&action=create">
        Ajouter une voiture
    </a>
</p>


<?php if (empty($tab_v)): ?>

    <p>
        Aucune voiture.
    </p>

<?php else: ?>

    <table border="1">

        <tr>
            <th>Immatriculation</th>
            <th>Marque</th>
            <th>Couleur</th>
            <th>Actions</th>
        </tr>


        <?php foreach ($tab_v as $v): ?>

            <tr>

                <td>
                    <?php echo htmlspecialchars($v->getImmatriculation()); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($v->getMarque()); ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($v->getCouleur()); ?>
                </td>

                <td>

                    <a href="index.php?controller=voiture&action=read&primary_value=<?php
                        echo rawurlencode($v->getImmatriculation());
                    ?>">
                        Détails
                    </a>

                    |

                    <a href="index.php?controller=voiture&action=update&primary_value=<?php
                        echo rawurlencode($v->getImmatriculation());
                    ?>">
                        Modifier
                    </a>

                    |

                    <a
                        href="index.php?controller=voiture&action=delete&primary_value=<?php
                            echo rawurlencode($v->getImmatriculation());
                        ?>"
                        onclick="return confirm('Voulez-vous vraiment supprimer cette voiture ?');"
                    >
                        Supprimer
                    </a>

                </td>

            </tr>

        <?php endforeach; ?>

    </table>

<?php endif; ?>
