<?php

$view_path = __DIR__
    . DIRECTORY_SEPARATOR
    . $controller
    . DIRECTORY_SEPARATOR
    . $view
    . ".php";

?>

<!DOCTYPE html>

<html lang="fr">

<head>

    <meta charset="UTF-8">

    <title>
        <?php echo htmlspecialchars($pagetitle); ?>
    </title>

</head>


<body>

<header>

    <h1>Site de covoiturage</h1>


    <nav>

        <a href="index.php">
            Accueil
        </a>

        |

        <a href="index.php?controller=voiture&action=readAll">
            Voitures
        </a>

        |

        <a href="index.php?controller=utilisateur&action=readAll">
            Utilisateurs
        </a>

        |

        <a href="index.php?controller=trajet&action=readAll">
            Trajets
        </a>

    </nav>


    <hr>

</header>


<main>

<?php

if (file_exists($view_path)) {

    require $view_path;

} else {

    echo "<p>Erreur : la vue demandée n'existe pas.</p>";
}

?>

</main>


<footer>

    <hr>

    <p>
        BTS SIO - SLAM - MVC
    </p>

</footer>


</body>

</html>
