<?php

require_once __DIR__ . '/../model/ModelUtilisateur.php';

class ControllerUtilisateur {

    protected static $object = 'utilisateur';


    // --------------------------------------------------
    // READ ALL
    // --------------------------------------------------

    public static function readAll() {

        $tab_u = ModelUtilisateur::selectAll();

        $controller = self::$object;
        $view = "list";
        $pagetitle = "Liste des utilisateurs";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // READ
    // --------------------------------------------------

    public static function read() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $u = ModelUtilisateur::select(
            $_GET['primary_value']
        );


        if ($u === false) {

            self::error();
            return;
        }


        $controller = self::$object;
        $view = "detail";
        $pagetitle = "Détail de l'utilisateur";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // CREATE
    // --------------------------------------------------

    public static function create() {

        $login = "";
        $nom = "";
        $prenom = "";

        $readonly = "";
        $required = "required";

        $action = "save";

        $controller = self::$object;
        $view = "update";
        $pagetitle = "Ajouter un utilisateur";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // SAVE
    // --------------------------------------------------

    public static function save() {

        $data = array(
            'login' => $_POST['login'],
            'nom' => $_POST['nom'],
            'prenom' => $_POST['prenom']
        );


        ModelUtilisateur::save($data);


        $login = $data['login'];

        $tab_u = ModelUtilisateur::selectAll();


        $controller = self::$object;
        $view = "created";
        $pagetitle = "Utilisateur créé";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // UPDATE
    // --------------------------------------------------

    public static function update() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $u = ModelUtilisateur::select(
            $_GET['primary_value']
        );


        if ($u === false) {

            self::error();
            return;
        }


        $login = $u->getLogin();
        $nom = $u->getNom();
        $prenom = $u->getPrenom();

        $readonly = "readonly";
        $required = "";

        $action = "updated";


        $controller = self::$object;
        $view = "update";
        $pagetitle = "Modifier un utilisateur";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // UPDATED
    // --------------------------------------------------

    public static function updated() {

        $data = array(
            'login' => $_POST['login'],
            'nom' => $_POST['nom'],
            'prenom' => $_POST['prenom']
        );


        ModelUtilisateur::update($data);


        $login = $data['login'];

        $tab_u = ModelUtilisateur::selectAll();


        $controller = self::$object;
        $view = "updated";
        $pagetitle = "Utilisateur modifié";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // DELETE
    // --------------------------------------------------

    public static function delete() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $login = $_GET['primary_value'];


        ModelUtilisateur::delete($login);


        $tab_u = ModelUtilisateur::selectAll();


        $controller = self::$object;
        $view = "deleted";
        $pagetitle = "Utilisateur supprimé";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // ERROR
    // --------------------------------------------------

    public static function error() {

        $controller = self::$object;
        $view = "error";
        $pagetitle = "Erreur";


        require __DIR__ . '/../view/view.php';
    }
}

?>
