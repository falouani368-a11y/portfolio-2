<?php

require_once __DIR__ . '/../model/ModelTrajet.php';

class ControllerTrajet {

    protected static $object = 'trajet';


    // --------------------------------------------------
    // READ ALL
    // --------------------------------------------------

    public static function readAll() {

        $tab_t = ModelTrajet::selectAll();

        $controller = self::$object;
        $view = "list";
        $pagetitle = "Liste des trajets";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // READ
    // --------------------------------------------------

    public static function read() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $t = ModelTrajet::select(
            $_GET['primary_value']
        );


        if ($t === false) {

            self::error();
            return;
        }


        $controller = self::$object;
        $view = "detail";
        $pagetitle = "Détail du trajet";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // CREATE
    // --------------------------------------------------

    public static function create() {

        $id = "";
        $depart = "";
        $arrivee = "";
        $date = "";
        $nbplaces = "";
        $prix = "";
        $conducteur_login = "";

        $readonly = "";
        $required = "required";

        $action = "save";


        $controller = self::$object;
        $view = "update";
        $pagetitle = "Ajouter un trajet";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // SAVE
    // --------------------------------------------------

    public static function save() {

        $data = array(
            'depart' => $_POST['depart'],
            'arrivee' => $_POST['arrivee'],
            'date' => $_POST['date'],
            'nbplaces' => $_POST['nbplaces'],
            'prix' => $_POST['prix'],
            'conducteur_login' => $_POST['conducteur_login']
        );


        ModelTrajet::save($data);


        $tab_t = ModelTrajet::selectAll();


        $controller = self::$object;
        $view = "created";
        $pagetitle = "Trajet créé";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // UPDATE
    // --------------------------------------------------

    public static function update() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $t = ModelTrajet::select(
            $_GET['primary_value']
        );


        if ($t === false) {

            self::error();
            return;
        }


        $id = $t->getId();
        $depart = $t->getDepart();
        $arrivee = $t->getArrivee();
        $date = $t->getDate();
        $nbplaces = $t->getNbplaces();
        $prix = $t->getPrix();
        $conducteur_login = $t->getConducteurLogin();


        $readonly = "readonly";
        $required = "";

        $action = "updated";


        $controller = self::$object;
        $view = "update";
        $pagetitle = "Modifier un trajet";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // UPDATED
    // --------------------------------------------------

    public static function updated() {

        $data = array(
            'id' => $_POST['id'],
            'depart' => $_POST['depart'],
            'arrivee' => $_POST['arrivee'],
            'date' => $_POST['date'],
            'nbplaces' => $_POST['nbplaces'],
            'prix' => $_POST['prix'],
            'conducteur_login' => $_POST['conducteur_login']
        );


        ModelTrajet::update($data);


        $tab_t = ModelTrajet::selectAll();


        $controller = self::$object;
        $view = "updated";
        $pagetitle = "Trajet modifié";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // DELETE
    // --------------------------------------------------

    public static function delete() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $id = $_GET['primary_value'];


        ModelTrajet::delete($id);


        $tab_t = ModelTrajet::selectAll();


        $controller = self::$object;
        $view = "deleted";
        $pagetitle = "Trajet supprimé";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // ERROR
    // --------------------------------------------------

    public static function error() {

        $controller = self::$object;
        $view = "error";
        $pagetitle = "Erreur";


        require __DIR__ . '/../view/view.php';
    }
}

?>
