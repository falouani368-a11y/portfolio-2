<?php

require_once "C:\\xampp\\htdocs\\MVC PHP TD5\\lib\\File.php";


// --------------------------------------------------
// CONTROLEUR PAR DEFAUT
// --------------------------------------------------

if (isset($_GET['controller'])) {

    $controller = $_GET['controller'];

} else {

    $controller = 'voiture';
}


// --------------------------------------------------
// ACTION PAR DEFAUT
// --------------------------------------------------

if (isset($_GET['action'])) {

    $action = $_GET['action'];

} else {

    $action = 'readAll';
}


// --------------------------------------------------
// CREATION DU NOM DE LA CLASSE
// --------------------------------------------------

$controller_class = 'Controller' . ucfirst($controller);


// --------------------------------------------------
// CREATION DU CHEMIN DU CONTROLEUR
// --------------------------------------------------

$controller_file = File::build_path(
    array(
        "controller",
        $controller_class . ".php"
    )
);


// --------------------------------------------------
// VERIFICATION ET CHARGEMENT DU CONTROLEUR
// --------------------------------------------------

if (file_exists($controller_file)) {

    require_once $controller_file;

} else {

    require_once File::build_path(
        array(
            "controller",
            "ControllerVoiture.php"
        )
    );

    ControllerVoiture::error();

    exit;
}


// --------------------------------------------------
// VERIFICATION DE L'ACTION
// --------------------------------------------------

$controller_methods = get_class_methods(
    $controller_class
);


if (in_array($action, $controller_methods)) {

    $controller_class::$action();

} else {

    if (in_array('error', $controller_methods)) {

        $controller_class::error();

    } else {

        ControllerVoiture::error();
    }
}

?>
