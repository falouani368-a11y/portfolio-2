<?php

require_once __DIR__ . '/../model/ModelVoiture.php';

class ControllerVoiture {

    protected static $object = 'voiture';


    // --------------------------------------------------
    // READ ALL
    // --------------------------------------------------

    public static function readAll() {

        $tab_v = ModelVoiture::selectAll();

        $controller = self::$object;
        $view = "list";
        $pagetitle = "Liste des voitures";

        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // READ
    // --------------------------------------------------

    public static function read() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }

        $v = ModelVoiture::select(
            $_GET['primary_value']
        );


        if ($v === false) {

            self::error();
            return;
        }


        $controller = self::$object;
        $view = "detail";
        $pagetitle = "Détail de la voiture";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // CREATE
    // --------------------------------------------------

    public static function create() {

        $immatriculation = "";
        $marque = "";
        $couleur = "";

        $readonly = "";
        $required = "required";

        $action = "save";

        $controller = self::$object;
        $view = "update";
        $pagetitle = "Ajouter une voiture";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // SAVE
    // --------------------------------------------------

    public static function save() {

        $data = array(
            'immatriculation' => $_POST['immatriculation'],
            'marque' => $_POST['marque'],
            'couleur' => $_POST['couleur']
        );


        ModelVoiture::save($data);


        $immat = $data['immatriculation'];

        $tab_v = ModelVoiture::selectAll();

        $controller = self::$object;
        $view = "created";
        $pagetitle = "Voiture créée";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // UPDATE
    // --------------------------------------------------

    public static function update() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $v = ModelVoiture::select(
            $_GET['primary_value']
        );


        if ($v === false) {

            self::error();
            return;
        }


        $immatriculation = $v->getImmatriculation();
        $marque = $v->getMarque();
        $couleur = $v->getCouleur();

        $readonly = "readonly";
        $required = "";

        $action = "updated";

        $controller = self::$object;
        $view = "update";
        $pagetitle = "Modifier une voiture";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // UPDATED
    // --------------------------------------------------

    public static function updated() {

        $data = array(
            'immatriculation' => $_POST['immatriculation'],
            'marque' => $_POST['marque'],
            'couleur' => $_POST['couleur']
        );


        ModelVoiture::update($data);


        $immat = $data['immatriculation'];

        $tab_v = ModelVoiture::selectAll();

        $controller = self::$object;
        $view = "updated";
        $pagetitle = "Voiture modifiée";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // DELETE
    // --------------------------------------------------

    public static function delete() {

        if (!isset($_GET['primary_value'])) {

            self::error();
            return;
        }


        $immat = $_GET['primary_value'];


        ModelVoiture::delete($immat);


        $tab_v = ModelVoiture::selectAll();


        $controller = self::$object;
        $view = "deleted";
        $pagetitle = "Voiture supprimée";


        require __DIR__ . '/../view/view.php';
    }


    // --------------------------------------------------
    // ERROR
    // --------------------------------------------------

    public static function error() {

        $controller = self::$object;
        $view = "error";
        $pagetitle = "Erreur";


        require __DIR__ . '/../view/view.php';
    }
}

?>
